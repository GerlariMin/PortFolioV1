<?php
  if(!isset($_SESSION)){
    session_start();
  }
  /*if(!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = "";
  }*/
?>
<?php

class Controller_annexes extends Controller {

    public function action_default(){
        $this->render("home");
    }

    public function action_pour_qui(){
      $this->render("pour_qui");
    }

    public function action_structures(){
      $this->render("structures");
    }

    public function action_professionnels_du_sport(){
      $this->render("professionnels_du_sport");
    }

    /*public function get_all_pratiquants(){
      $m=Model::get_model();
      $t=$m->get_all_users();
    }*/

    public function action_pratiquants(){
      /*$m=Model::get_model();
      $t=$m->get_all_users();*/
      $this->render("pratiquants"/*, $t*/);
    }

    public function action_professionnels_de_sante(){
      $this->render("professionnels_de_sante");
    }

    public function action_aidants(){
      $this->render("aidants");
    }

    public function action_parents(){
      $this->render("parents");
    }

    public function action_enfants_et_adolescents(){
      $this->render("enfants_et_adolescents");
    }

    public function action_services(){
      $this->render("services");
    }

    public function action_le_centre(){
      $this->render("le_centre");
    }

    public function action_conferences(){
      $this->render("conferences");
    }

    public function action_formation(){
      $this->render("formation");
    }

    public function action_activite_physique_adaptee(){
      $this->render("activite_physique_adaptee");
    }

    public function action_programme_APA(){
      $this->render("programme_APA");
    }

    public function action_conseils_en_activite_physique(){
      $this->render("conseils_en_activite_physique");
    }

    public function action_evaluation_de_la_condition_physique(){
      $this->render("evaluation_de_la_condition_physique");
    }

    public function action_tarifs(){
      $this->render("tarifs");
    }

    public function action_contact(){
      $this->render("contact");
    }

    public function action_a_propos(){
      $this->render("a_propos");
    }

    public function action_equipe(){
      $this->render("equipe");
    }

    public function action_blog(){
      $this->render("blog");
    }

    public function action_enseignant_APA(){
      $this->render("enseignant_APA");
    }

    /*public function action_agenda(){
      $this->render("agenda");
    }*/
}

?>
