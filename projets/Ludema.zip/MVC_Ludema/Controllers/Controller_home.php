<?php
  if(!isset($_SESSION)){
    session_start();
  }
  /*if(!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = "";
  }*/
?>
<?php

class Controller_home extends Controller {

    public function action_default(){
        $this->action_home();
    }

    public function action_home(){
        $this->render("home");
    }
}

?>
