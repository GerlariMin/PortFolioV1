<?php
  if(!isset($_SESSION)){
    session_start();
  }
  /*if(!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = "";
  }*/
?>
<?php

  class Controller_inscription extends Controller{

      public function action_default(){
              $this->action_connexion();//action_menu_inscription();
        }

        /*public function action_menu_inscription(){
          $this->render("connexion");
        }*/

        public function action_inscription(){ //appel du formulaire
          $this->render("inscription");
        }

        public function action_connexion(){
          $this->render("se_connecter");
        }

        public function action_ajouter_user(){ // apres saisie du formulaire
          //require_once("Model/Model.php");
          $m = Model::get_model();
          if( (isset($_POST['pswd']) & trim($_POST['pswd'])!="")
              && (isset($_POST['conf_pswd']) & trim($_POST['conf_pswd'])!="")
              && (trim($_POST['pswd'])==trim($_POST['conf_pswd']))
          ){
            if( (isset($_POST['user_id']) & trim($_POST['user_id'])!="")
                && (isset($_POST['nom']) & trim($_POST['nom'])!="")
                && (isset($_POST['prenom']) & trim($_POST['prenom'])!="")
                && (isset($_POST['age']) & trim($_POST['age'])!="")
                && (isset($_POST['phone']) & trim($_POST['phone'])!="")
                && (isset($_POST['mail']) & trim($_POST['mail'])!="")
            ){
                $_SESSION['user_id']=$_POST['user_id'];
                $user_id = $_POST['user_id'];
                $_SESSION['nom']=$_POST['nom'];
                $nom = $_POST['nom'];
                $_SESSION['prenom']=$_POST['prenom'];
                $prenom = $_POST['prenom'];
                $_SESSION['age']=$_POST['age'];
                $age = $_POST['age'];
                $_SESSION['phone']=$_POST['phone'];
                $phone = $_POST['phone'];
                $_SESSION['mail']=$_POST['mail'];
                $mail = $_POST['mail'];
                //$_SESSION['pswd']=$_POST['pswd'];
                $pswd = $_POST['pswd'];

                //$this->action_error($m->get_user('ryan'));
                //on envoit un mail de confirmation
					      /*$mail=$_POST['Mail'];
                $nom=$_POST['Nom'];
      					$objet = 'Confirmation de votre adresse' ;
                $contenu = '<html>
                              <head>
										                    <title>Vous avez créé un compte sur notre site</title>
									            </head>
									            <body>
										                    <p>Bonjour Mr/Mmme '.$nom.'</p>
										                    <p>Ce mail est généré automatiquement suite à la création de votre compte sur Ludema.</p>
									            </body>
								            </html>';
                $entetes = 'Content-type: text/html; charset=utf-8' . "\r\n" . 'From: Ludema@gmail.com' . "\r\n" . 'Reply-To: email@domain.tld' . "\r\n" . 'X-Mailer: PHP/' . phpversion();
                ini_set('SMTP','smtp.free.fr');
                ini_set('sendmail_from', 'hornitzaile@hotmail.fr');
					      //Envoi du mail
      					if(mail($mail, $objet, $contenu, $entetes)){
                  $data = [
              			'title' => "Error",
              			'message' => "Le mail a été evoyé avec succès"
              		];
      						$this->render("message",$data);
      					}else{
      						$this->action_error("Le mail n'a pas pu être envoyé");
      					}*/

                $valeur=$m->add_user($user_id, $nom, $prenom, $age, $phone, $mail, $pswd); //soit on met les infos dans un tableau soit on utilise la session
                if($valeur==true){
                  $data = ['title' => "Enregistrement",
                        'message' => "Création de compte réussi !"
                      ];
                  $_SESSION['user_id']=$_POST['user_id'];
                  $this->render("message",$data);
                }else{
                  $_SESSION['user_id']="";
                  session_destroy();
                  $this->action_error("Problème lors de la création du compte !");
                }
                //$this->action_error();
            }else{
              $_SESSION['user_id']="";
              session_destroy();
              $this->action_error("Problème de saisie dans le formulaire !");
              //sleep(1000);
              //$this->action_inscription();
            }
          }else{
            $_SESSION['user_id']="";
            session_destroy();
            $this->action_error("La confirmation de mot de passe ne correspond pas !");
            //sleep(1000);
            //$this->action_inscription();
          }
        }

        public function action_verifier_user(){
          //echo "verification en cours";
          if(isset($_POST['pswd']) & trim($_POST['pswd']!="")){
            //echo "bon mdp";
            //print_r($_POST);
            if(isset($_POST['user_id']) & trim($_POST['user_id'])!=""){
              //print_r($_POST);
              //echo "bon id";
              $u_id=$_POST['user_id'];
              $p=$_POST['pswd'];
              $m = Model::get_model();
              $val = $m->verif_user($u_id, $p);
              //echo $val;
              if($val==true){
                //print_r($_POST);
                $_SESSION['user_id']=$u_id;
                $t= $m->get_user($u_id);
                //print_r($t);
                foreach($t as $c=>$v){
                    $_SESSION['nom']=$v['nom'];
                    $_SESSION['prenom']=$v['prenom'];
                    $_SESSION['age']=$v['age'];
                    $_SESSION['phone']=$v['phone'];
                    $_SESSION['mail']=$v['email'];
                }

                //$this->render("profil");
                //$this->action_profil();
                $data = [
            			'title' => "Connexion au compte",
            			'message' => "Connexion réussie"
            		];
                $this->render("message", $data);
              }else{
                $this->action_error("Les informations saisies ne correspondent à aucun compte !");
              }
            }else{
              $this->action_error("Identifiant manquant");
            }
          }else{
            $this->action_error("Mot de passe manquant");
          }
        }

        /*public function action_profil(){ //afficage global du profil
          //echo 'je passe dans profil';
          $m=Model::get_model();
          $t = $m->get_user($_SESSION['user_id']);

          foreach($t as $c => $v){
            $_SESSION['prenom'] = $v['prenom'];
            $_SESSION['nom'] = $v['nom'];
            $_SESSION['age'] = $v['age'];
            $_SESSION['mail'] = $v['email'];
            $_SESSION['phone'] = $v['phone'];
          }

          $this->render("profil");
        }*/
      }
?>
