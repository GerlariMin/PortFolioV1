<?php
  if(!isset($_SESSION)){
    session_start();
  }
?>
<?php
  class Controller_pro extends Controller {

    public function action_default(){
        $this->render("home");
    }
    public function action_verifier_pro(){
      $m = Model::get_model();
      $val = $m->verif_pro($_SESSION['sport']);

      $val2 = $m->verif_horaire($_POST['dates'],$_POST['heure']);

      $val3 = $m->horaire_libre($_POST['dates'],$_POST['heure'],$_SESSION['user_id']);

      $data = ["list_pro"=>$val,
                "list_horaire"=>$val2,
                "horaire_libre"=>$val3,
                "dates"=>$_POST['dates'],
                "heure"=>$_POST['heure'],];

      $this->render("prodispo", $data);
    }

    public function action_horaire(){
      $this->render("horaire");
    }


    public function action_add_rdv(){
      $m = Model::get_model();
      /*print_r($_GET['nom']);
      print_r($_GET['prenom']);
      print_r($_GET['dates']);
      print_r($_GET['heure']);
      print_r($_GET['id_client']);
      print_r($_GET['sport']);*/
      $val = $m->add_rdv($_GET['nom'],$_GET['prenom'],$_GET['dates'],$_GET['heure'],$_GET['id_client'],$_GET['sport']);
      $data = ['title' => "Enregistrement",
               'message' => "Réservation réussi !"];
      $this->render("message",$data);
    }


    public function action_remove(){
      $m = Model::get_model();
      $t = $m->remove_rdv($_GET['heure'],$_GET['jour']);
      $data = [
                  'title' => "Suppression du RDV",
                  'message' => "suppression réussie"
                ];
      $this->render("message", $data);

    }
  }








?>
