<?php
  if(!isset($_SESSION)){
    session_start();
  }
/*  if(!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = "";
  }*/
?>

<?php

class Controller_profil extends Controller {

    public function action_default(){
        $this->action_modification();
    }

    public function action_profil(){ //afficage global du profil
      //echo 'je passe dans profil';
      $m=Model::get_model();
      $t = $m->get_user($_SESSION['user_id']);

      foreach($t as $c => $v){
        $_SESSION['prenom'] = $v['prenom'];
        $_SESSION['nom'] = $v['nom'];
        $_SESSION['age'] = $v['age'];
        $_SESSION['mail'] = $v['email'];
        $_SESSION['phone'] = $v['phone'];
      }

      $this->render("profil");
    }

    public function action_suivi(){
      require('Content/pdf/tfpdf.php');

      $pdf = new tFPDF();
      $pdf->AddPage();

      // Ajoute une police Unicode (utilise UTF-8)
      $pdf->AddFont('DejaVu','','DejaVuSansCondensed.ttf',true);
      $pdf->SetFont('DejaVu','',14);

      // En-tête
      // Logo
      $pdf->Image('Content/img/ludema.png',10,6,30);
      // Police Arial gras 15
      $pdf->SetFont('Arial','B',15);
      // Décalage à droite
      //$pdf->Cell(80);
      // Charge une chaîne UTF-8 à partir d'un fichier
      $txt = file_get_contents('Content/pdf/Fiche_Suivi.txt');
      $pdf->Write(8,$txt);
      // Titre
      //$pdf->Cell(30,10,$txt,1,0,'C');
      // Saut de ligne
      $pdf->Ln(20);

      // Sélectionne une police standard (utilise windows-1252)
      $pdf->SetFont('Arial','',14);
      $pdf->Ln(10);
      $pdf->Write(5,"Nom: ".$_SESSION['nom']."\n\n");
      $pdf->Write(5,"Prenom: ".$_SESSION['prenom']."\n\n");
      $pdf->Write(5,"Adresse mail: ".$_SESSION['mail']."\n\n");
      $pdf->Write(5,"Numero de telephone: ".$_SESSION['phone']."\n\n");
      $pdf->Write(5,"Age: ".$_SESSION['age']."\n\n");
      $pdf->Write(5,"Taille: "."\n\n");
      $pdf->Write(5,"Poids: "."\n\n");
      $pdf->Write(5,"Condition physique: \n\n");
      $pdf->Ln(150);
      //$pdf->Write(5,"Fiche generee automatique par LUDEMA");

      // Pied de page
      // Positionnement à 1,5 cm du bas
      $pdf->SetY(-15);
      // Police Arial italique 8
      $pdf->SetFont('Arial','I',8);
      // Numéro de page
      $pdf->Cell(0,10,'Page '.$pdf->PageNo().'/1',0,0,'C');

      $pdf->Output();
    }

    public function action_agenda(){
      $m=Model::get_model();
      $t = $m->get_rdv($_SESSION['user_id']);
      $data = ["list_rdv"=>$t];

      $this->render("agenda", $data);
    }

    public function action_sport(){
      $this->render("sport");
    }

    public function action_modification(){
      $this->render("modification");
    }

    public function action_valider_modification(){
      $m=Model::get_model();
      $modif=[];
      if(isset($_POST['user_id']) & trim($_POST['user_id'])!=""){
        //echo "user_id detecte";
        $modif['user_id']=$_POST['user_id'];
      }
      if(isset($_POST['nom']) & trim($_POST['nom'])!=""){
        //echo "nom detecte";
        $modif['nom']=$_POST['nom'];
      }
      if(isset($_POST['prenom']) & trim($_POST['prenom'])!=""){
        //echo "prenom detecte";
        $modif['prenom']=$_POST['prenom'];
      }
      if(isset($_POST['age']) & trim($_POST['age'])!=""){
        //echo "age detecte";
        $modif['age']=$_POST['age'];
      }
      if(isset($_POST['mail']) & trim($_POST['mail'])!=""){
        //echo "mail detecte";
        $modif['mail']=$_POST['mail'];
      }
      if(isset($_POST['phone']) & trim($_POST['phone'])!=""){
        //echo "num tel detecte";
        $modif['phone']=$_POST['phone'];
      }
      if(isset($_POST['pswd']) & trim($_POST['pswd'])!="" & $m->verif_user($_SESSION['user_id'],$_POST['pswd'])==true){
        if( (isset($_POST['new_pswd']) & trim($_POST['new_pswd'])!="")
          & (isset($_POST['conf_new_pswd']) & trim($_POST['conf_new_pswd'])!="") ){
            $modif['new_pswd']=$_POST['conf_new_pswd'];
        } else{
          $this->action_error("le nouveau mot de passe n'est pas identique sur les deux champs");
        }
      }
      //print_r($modif);

      $t=$m->modifier_user($modif);
      if($t!=false){
        $data = ['title' => "Enregistrement",
              'message' => "Modifications réussies !"
            ];
        if(isset($modif['user_id']) /*& trim($modif['user_id'])!=""*/){
          if(trim($modif['user_id'])!=""){
              $_SESSION['user_id']=$modif['user_id'];
          }
        }
        $this->render("message",$data);
      }else{
        $this->action_error("Erreur lors de la modification des informations du profil !");
      }
    }

    public function action_materiel(){
      if(isset($_POST['materiel']) & trim($_POST['materiel'])!=""){
        $m=Model::get_model();
        $m->add_materiel($_POST['materiel']);
        $this->render("profil");
      }
    }

    public function action_lieu(){
      if(isset($_POST['lieu']) & trim($_POST['lieu'])!=""){
        $m=Model::get_model();
        $m->add_lieu($_POST['lieu']);
        $this->render("profil");
      }
    }

    public function action_disconnect(){
      session_destroy();
      $_SESSION['user_id']="";
      $this->render("home");
    }

    public function action_remove(){
      $m = Model::get_model();
      $t = $m->remove_user($_SESSION['user_id']);
      $data = [
                  'title' => "Suppression du compte",
                  'message' => "suppression réussie"
                ];
      $this->render("message", $data);

    }
}

?>
