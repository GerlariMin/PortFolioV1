<?php
  if(!isset($_SESSION)){
    session_start();
  }
  /*if(!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = "";
  }*/
?>

<?php

class Model {

    private static $instance = null;

    private function __construct(){

      try{
        $this->bd = new PDO('mysql:host=localhost;dbname=ludema','root','');//sur serveur dbname=id8293898_client login ='id8293898_admin' et mdp ='rootadmin'
      }catch(PDOException $e){
        $erreur = 'Connexion échouée: '. $e->getMessage();
        $this->action_error($erreur);
      }

    }

    public static function get_model(){

        if(is_null(self::$instance)){
            self::$instance = new Model();
        }
        return self::$instance;
    }

    public function add_user($user_id, $nom, $prenom, $age, $phone, $mail, $pswd){
      try{
        $req = $this->bd->prepare("INSERT INTO client (user_id, pswd, email, nom, prenom, age, phone, materiel, lieu) VALUES (:id_user, :pswd, :mail, :nom, :prenom, :age, :phone, '','');");
        $req->bindValue(":id_user", $user_id);
        $req->bindValue(":nom", $nom);
        $req->bindValue(":prenom", $prenom);
        $req->bindValue(":age", $age);
        $req->bindValue(":phone", $phone);
        $req->bindValue(":mail", $mail);
        $pswdC=password_hash($pswd, PASSWORD_DEFAULT);
        $req->bindValue(":pswd", $pswdC);
        if($req->execute()){
          return true;
        }else{
          return false;
        }
      }catch(PDOException $e){
        $erreur = "Problème lors de la création du compte: " . $e->getMessage();
        $this->action_error($erreur);
      }
    }

    //fonction pour récupérer les infos utilisateurs
    public function get_user($n){
      $req = $this->bd->prepare("SELECT * FROM client WHERE user_id = :u;");
      $req->bindValue(":u", $n);
      $req->execute();
      $t = $req->fetchAll(PDO::FETCH_ASSOC);

      return $t;
    }

    public function get_all_users(){
      $req = $this->bd->prepare("SELECT nom, prenom FROM client;");
      $req->execute();

      return $req->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_all_pro(){
      $req = $this->bd->prepare("SELECT nom, prenom FROM pro;");
      $req->execute();

      return $req->fetchAll(PDO::FETCH_ASSOC);
    }

    public function verif_user($nom_user, $mdp){
        try{
            $req = $this->bd->prepare("SELECT pswd FROM client WHERE user_id  = :id;");
            $req->bindValue(":id", $nom_user);
            $req->execute();
            $t = $req->fetch(PDO::FETCH_ASSOC);

            $b = false;
            if($t==false){
              $b = false;
            }else{
              if(password_verify($mdp,$t['pswd'])){
                $b=true;
              }
            }
            return $b;
          }catch(PDOException $e){
            $erreur = "Problème lors de la vérification du compte: " . $e->getMessage();
            $this->action_error($erreur);
        }
    }
    public function verif_pro($sport){
        try{
          $req = $this->bd->prepare("SELECT * FROM pro WHERE sport =:sport ;");
          $req->bindValue(":sport", $sport);
          $req->execute();
          $t = $req->fetchall();

          return $t;

          }catch(PDOException $e){
            $erreur = "Problème lors de la vérification du professionnels: " . $e->getMessage();
            $this->action_error($erreur);
        }
    }

    public function verif_horaire($dates,$horaire){
        try{
          $req = $this->bd->prepare("SELECT * FROM horaire_p WHERE dates  = :dates AND horaire = :horaire;");
          $req->bindValue(":dates", $dates);
          $req->bindValue(":horaire", $horaire);
          $req->execute();
          $t = $req->fetchall(PDO::FETCH_ASSOC);

          return $t;

        }catch(PDOException $e){
          $erreur = "Problème lors de la vérification des horaires : " . $e->getMessage();
          $this->action_error($erreur);
        }
    }

    public function add_rdv($nom,$prenom,$dates,$horaire,$id_client,$sport){
        try{
          $req = $this->bd->prepare("INSERT INTO `horaire_p`(`nom`, `prenom`, `dates`, `horaire`, `id_client`, `sport`) VALUES (:nom,:prenom,:dates,:horaire,:id_client,:sport);");
          $req->bindValue(":nom", $nom);
          $req->bindValue(":prenom", $prenom);
          $req->bindValue(":dates", $dates);
          $req->bindValue(":horaire", $horaire);
          $req->bindValue(":id_client", $id_client);
          $req->bindValue(":sport", $sport);
          $req->execute();

          return true;

        }catch(PDOException $e){
          $erreur = "Problème lors de la reservation : " . $e->getMessage();
          $this->action_error($erreur);
        }
    }

    public function modifier_user($tab){
      try{
			$up="UPDATE client SET ";

      if(isset($tab['user_id'])){
        if(trim($up)!="UPDATE client SET"){
          $up =$up.', ';
        }
        $up=$up."user_id = :id";
      }
      if(isset($tab['nom'])){
        if(trim($up)!="UPDATE client SET"){
          $up =$up.', ';
        }
        $up=$up."nom = :n";
      }
      if(isset($tab['prenom'])){
        if(trim($up)!="UPDATE client SET"){
          $up =$up.', ';
        }
        $up=$up."prenom = :p";
      }
      if(isset($tab['age'])){
        if(trim($up)!="UPDATE client SET"){
          $up =$up.', ';
        }
        $up=$up."age = :a";
      }
      if(isset($tab['mail'])){
        if(trim($up)!="UPDATE client SET"){
          $up =$up.', ';
        }
        $up=$up."email = :m";
      }
      if(isset($tab['new_pswd'])){
        if(trim($up)!="UPDATE client SET"){
          $up =$up.', ';
        }
        $up=$up."pswd = :pswd";
      }
      $up=$up." WHERE user_id = :ex_id;";
			$req= $this->bd->prepare($up);

      $req->bindValue(':ex_id', $_SESSION['user_id']);
      if(isset($tab['user_id'])){
        $req->bindValue(':id', $tab['user_id']);
      }
      if(isset($tab['nom'])){
        $req->bindValue(':n', $tab['nom']);
      }
      if(isset($tab['prenom'])){
        $req->bindValue(':p', $tab['prenom']);
      }
      if(isset($tab['age'])){
        $req->bindValue(':a', $tab['age']);
      }
      if(isset($tab['mail'])){
        $req->bindValue(':m', $tab['mail']);
      }
      if(isset($tab['new_pswd'])){
        $req->bindValue(':pswd', password_hash($tab['new_pswd'], PASSWORD_DEFAULT));
      }

			//Exécution de la requête
			return $req->execute();

		}catch(PDOException $e){
      $erreur = "Problème lors de la modification: " . $e->getMessage();
      $this->action_error($erreur);
    }
    }

    public function add_lieu($l){
      try{
        $req= $this->bd->prepare('UPDATE client SET lieu = :l WHERE user_id = :id;');
        $req->bindValue(':l',$l);
        $req->bindValue(':id', $_SESSION['user_id']);
        $req->execute();

      }catch(PDOException $e){
        $erreur = "Problème lors de l'ajout de la préférence du lieu:' " . $e->getMessage();
        $this->action_error($erreur);
      }
    }

    public function get_rdv($id){
      try{
        $req= $this->bd->prepare('select * from horaire_p WHERE id_client = :id;');
        $req->bindValue(':id',$id);
        $req->bindValue(':id', $_SESSION['user_id']);
        $req->execute();
        $t = $req->fetchall(PDO::FETCH_ASSOC);

        return $t;

      }catch(PDOException $e){
        $erreur = "Problème lors de l'affichage des RDV:' " . $e->getMessage();
        $this->action_error($erreur);
      }
    }


    public function add_materiel($m){
      try{
        $req= $this->bd->prepare('UPDATE client SET materiel = :m WHERE user_id = :id;');
        $req->bindValue(':m',$m);
        $req->bindValue(':id', $_SESSION['user_id']);
        $req->execute();

      }catch(PDOException $e){
        $erreur = "Problème lors de l'ajout de la préférence du lieu:' " . $e->getMessage();
        $this->action_error($erreur);
      }
    }

    public function horaire_libre ($dates,$horaire,$id){
        try{
          $req = $this->bd->prepare("SELECT * FROM horaire_p WHERE dates  = :dates AND horaire = :horaire AND id_client =:id;");
          $req->bindValue(":dates", $dates);
          $req->bindValue(":horaire", $horaire);
          $req->bindValue(":id", $id);
          $req->execute();
          $t = $req->fetchall(PDO::FETCH_ASSOC);
          if($t==false){
            return true;
          }else{
            return false;
          }

        }catch(PDOException $e){
          $erreur = "Problème lors de la vérification des horaires : " . $e->getMessage();
          $this->action_error($erreur);
        }
    }

    public function remove_user($id){
      try{
        $req = $this->bd->prepare("DELETE FROM client WHERE user_id = :id;");
        $req->bindValue(":id", $id);
        return $req->execute();
      }catch(PDOException $e){
        $erreur = "Problème lors de la suppression: " . $e->getMessage();
        $this->action_error($erreur);
      }
    }
    public function remove_rdv($heure,$jour){
      try{
        $req = $this->bd->prepare("DELETE FROM horaire_p WHERE horaire = :heure AND dates= :jour;");
        $req->bindValue(":heure", $heure);
        $req->bindValue(":jour", $jour);
        return $req->execute();
      }catch(PDOException $e){
        $erreur = "Problème lors de la suppression: " . $e->getMessage();
        $this->action_error($erreur);
      }
    }
}

?>
