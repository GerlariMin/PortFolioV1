-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- H�te : 127.0.0.1
-- G�n�r� le :  lun. 14 jan. 2019 � 22:44
-- Version du serveur :  10.1.37-MariaDB
-- Version de PHP :  7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de donn�es :  `ludema`
--

-- --------------------------------------------------------

--
-- Structure de la table `horaire_p`
--

CREATE TABLE `horaire_p` (
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `dates` date NOT NULL,
  `horaire` varchar(255) NOT NULL,
  `id_client` varchar(255) NOT NULL,
  `sport` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- D�chargement des donn�es de la table `horaire_p`
--

INSERT INTO `horaire_p` (`nom`, `prenom`, `dates`, `horaire`, `id_client`, `sport`) VALUES
('salah', 'karim', '2019-01-12', '8h-9h', 'test', 'musculation'),
('leta', 'less', '2019-01-04', '9h-10h', 'test', 'natation'),
('salah', 'karim', '2019-01-12', '10h-12h', 'test', 'musculation'),
('salah', 'karim', '2019-01-31', '16h-18h', 'test', 'musculation');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

