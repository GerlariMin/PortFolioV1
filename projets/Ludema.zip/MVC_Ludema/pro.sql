-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  lun. 14 jan. 2019 à 22:44
-- Version du serveur :  10.1.37-MariaDB
-- Version de PHP :  7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ludema`
--

-- --------------------------------------------------------

--
-- Structure de la table `pro`
--

CREATE TABLE `pro` (
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `sport` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `pro`
--

INSERT INTO `pro` (`nom`, `prenom`, `sport`, `mail`, `phone`) VALUES
('salah', 'karim', 'musculation', 'karim.salah@gmail.com', 645986221),
('jac', 'jean', 'musculation', 'jean.jac@gmail.com', 768986221),
('dupuis', 'camille', 'musculation', 'camille.dupuis@gmail.com', 645963421),
('leta', 'less', 'natation', 'less.leta@gmail.com', 745986221);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
