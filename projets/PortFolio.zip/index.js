
function route(){

	var hash=window.location.hash;

	switch(hash){

		case("#cedr"):
			$.get("projets.html", function(reponse){
				content = $(reponse).filter("#cedr").html();
				$("#container").html(content);
			}, "html");
			break;

		case("#competences"):
			$.get("info.html", function(reponse){
				content = $(reponse).filter("#competences").html();
				$("#container").html(content);
			}, "html");
			break;

		/*case("#complements"):
			$.get("info.html", function(reponse){
				content = $(reponse).filter("#complements").html();
				$("#container").html(content);
			}, "html");
			break;*/

		case("#contact"):
			$.get("info.html", function(reponse){
				content = $(reponse).filter("#contact").html();
				$("#container").html(content);
			}, "html");
			break;

		case("#cv"):
			$.get("info.html", function(reponse){
				content = $(reponse).filter("#cv").html();
				$("#container").html(content);
			}, "html");
			break;

		case("#echecs"):
			$.get("projets.html", function(reponse){
				content = $(reponse).filter("#echecs").html();
				$("#container").html(content);
			}, "html");
			break;

		case("#experiences"):
			$.get("info.html", function(reponse){
				content = $(reponse).filter("#experiences").html();
				$("#container").html(content);
			}, "html");
			break;

		case("#historique"):
			$.get("info.html", function(reponse){
				content = $(reponse).filter("#historique").html();
				$("#container").html(content);
			}, "html");
			break;

		case("#loutrebay"):
			$.get("projets.html", function(reponse){
				content = $(reponse).filter("#loutrebay").html();
				$("#container").html(content);
			}, "html");
			break;

		case("#ludema"):
			$.get("projets.html", function(reponse){
				content = $(reponse).filter("#ludema").html();
				$("#container").html(content);
			}, "html");
			break;

		case("#mmo"):
			$.get("projets.html", function(reponse){
				content = $(reponse).filter("#mmo").html();
				$("#container").html(content);
			}, "html");
			break;

		case("#parcours"):
			$.get("info.html", function(reponse){
				content = $(reponse).filter("#parcours").html();
				$("#container").html(content);
			}, "html");
			break;

		case("#portfolio"):
			$.get("projets.html", function(reponse){
				content = $(reponse).filter("#portfolio").html();
				$("#container").html(content);
			}, "html");
			break;

		case("#presentation"):
			$.get("info.html", function(reponse){
				content = $(reponse).filter("#presentation").html();
				$("#container").html(content);
			}, "html");
			break;

		case("#retrogames"):
			$.get("projets.html", function(reponse){
				content = $(reponse).filter("#retrogames").html();
				$("#container").html(content);
			}, "html");
			break;

		default:
			$.get("info.html", function(reponse){
				content = $(reponse).filter("#home").html();
				$("#container").html(content);
			}, "html");
			break;

	}
}

$(document).ready(function(){
	route();
	$(window).on("hashchange", function(){
		route();
	});

});
