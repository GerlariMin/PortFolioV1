({
  'apos': "'",
  'control': 'X'
});
