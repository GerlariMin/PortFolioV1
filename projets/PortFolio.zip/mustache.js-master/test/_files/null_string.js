({
  name: 'Elise',
  glytch: true,
  binary: false,
  value: null,
  undef: undefined,
  numeric: function () {
    return NaN;
  }
});
