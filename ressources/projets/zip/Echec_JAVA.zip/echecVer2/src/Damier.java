import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
/*import javax.swing.JLabel;*/
import javax.swing.JPanel;
	
public class Damier extends JFrame {/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//tab[i][j] == pionplat[][], pour actualiser regarder les mouvements possible et mouselistener

	JPanel [][]tab=new JPanel[8][8];
	Container cf=getContentPane();
	//JLabel lab = new JLabel(new ImageIcon("C:/User/gerla/workspace/pion.png"));
	
	/*Constructeur*/ 
	public Damier(){
	setTitle("Echecs");
	cf.setLayout(new GridLayout(1,8));
	JPanel p1=new JPanel();
	
	/*Plateau*/
	p1.setLayout(new GridLayout(8,8,5,5));
	/*for(int i=0;i<=7;i++){
		for(int j=0;j<=7;j++){
			tab[i][j]=new JPanel();
			p1.add(tab[i][j]);
			System.out.println("Init: fait" +" " +i +" " +j +" " +p1);
		}
	}*/
	
	for(int i=0;i<=7;i++){
		for(int j=0;j<=7;j++){
			tab[i][j]=new JPanel(); //on indique quon creer un tab de Jpanel
			if(((i+j)%2)==0){ //si indice pair
				tab[i][j].setBackground(Color.black); //fond case noir
				p1.add(tab[i][j]); //on ajoute au panel p1 la case du tableau de panel
				System.out.println("casenoire: fait" +" " +i +" " +j);
			}
			
			else if(((i+j)%2)==1){ 
				tab[i][j].setBackground(Color.gray); //si indice impair on met en gris
				p1.add(tab[i][j]); 
				System.out.println("casegrise: fait" +" " +i +" " +j);
			}
		
		if(i==1 && j<=7){
			JLabel lab = new JLabel(new ImageIcon("piono.png")); //on declare limage quon va inserer dans tab puis dans p1
			//lab.setBounds(x, y, width, height);
			tab[i][j].add(lab);
			p1.add(tab[i][j]);
			System.out.println("lab: fait" +" " +i +" " +j);
			}
		
		else if(i==6 && j<=7){
			JLabel lab1 = new JLabel(new ImageIcon("pionb.png")); 
			//lab1.setBounds(x, y, width, height);
			tab[i][j].add(lab1);
			p1.add(tab[i][j]);
			System.out.println("lab1: fait" +" " +i +" " +j);
			}
		
		if((i==0 && j==0) || (i==0 && j==7)){
			JLabel lab2 = new JLabel(new ImageIcon("touro.png")); 
			//lab1.setBounds(x, y, width, height);
			tab[i][j].add(lab2);
			p1.add(tab[i][j]);
			System.out.println("lab2: fait" +" " +i +" " +j);
			}
		
		else if((i==7 && j==7) || (i==7 && j==0)){
			JLabel lab3 = new JLabel(new ImageIcon("tourb.png")); 
			//lab1.setBounds(x, y, width, height);
			tab[i][j].add(lab3);
			p1.add(tab[i][j]);
			System.out.println("lab3: fait" +" " +i +" " +j);
			}
		
		if((i==0 && j==1) || (i==0 && j==6)){
			JLabel lab4 = new JLabel(new ImageIcon("cavaliero.png")); 
			//lab1.setBounds(x, y, width, height);
			tab[i][j].add(lab4);
			p1.add(tab[i][j]);
			System.out.println("lab4: fait" +" " +i +" " +j);
			}
		
		else if((i==7 && j==1) || (i==7 && j==6)){
			JLabel lab5 = new JLabel(new ImageIcon("cavalierb.png")); 
			//lab1.setBounds(x, y, width, height);
			tab[i][j].add(lab5);
			p1.add(tab[i][j]);
			System.out.println("lab5: fait" +" " +i +" " +j);
			}
		
		if((i==0 && j==2) || (i==0 && j==5)){
			JLabel lab6 = new JLabel(new ImageIcon("fouo.png")); 
			//lab1.setBounds(x, y, width, height);
			tab[i][j].add(lab6);
			p1.add(tab[i][j]);
			System.out.println("lab6: fait" +" " +i +" " +j);
			}
		
		else if((i==7 && j==2) || (i==7 && j==5)){
			JLabel lab7 = new JLabel(new ImageIcon("foub.png")); 
			//lab1.setBounds(x, y, width, height);
			tab[i][j].add(lab7);
			p1.add(tab[i][j]);
			System.out.println("lab7: fait" +" " +i +" " +j);
			}
		
		if((i==0 && j==3)){
			JLabel lab7 = new JLabel(new ImageIcon("roio.png")); 
			//lab1.setBounds(x, y, width, height);
			tab[i][j].add(lab7);
			p1.add(tab[i][j]);
			System.out.println("lab7: fait" +" " +i +" " +j);
			}
		
		else if((i==7 && j==4)){
			JLabel lab8 = new JLabel(new ImageIcon("roib.png")); 
			//lab1.setBounds(x, y, width, height);
			tab[i][j].add(lab8);
			p1.add(tab[i][j]);
			System.out.println("lab8: fait" +" " +i +" " +j);
			}
		
		if((i==0 && j==4)){
			JLabel lab9 = new JLabel(new ImageIcon("reineo.png")); 
			//lab1.setBounds(x, y, width, height);
			tab[i][j].add(lab9);
			p1.add(tab[i][j]);
			System.out.println("lab9: fait" +" " +i +" " +j);
			}
		
		else if((i==7 && j==3)){
			JLabel lab10 = new JLabel(new ImageIcon("reineb.png")); 
			//lab1.setBounds(x, y, width, height);
			tab[i][j].add(lab10);
			p1.add(tab[i][j]);
			System.out.println("lab10: fait" +" " +i +" " +j);
			}
		}
	
	
	cf.add(p1);
	

	/*Centrer la fenetre*/
	Dimension screenSize =Toolkit.getDefaultToolkit().getScreenSize();
	pack();
	setLocation((screenSize.width-getWidth())/2,(screenSize.height-getHeight())/2);
	
	/*Actualiser l'image des pieces en fonction du deplacement*/
/*	public Damier(testDeplacement(), int x, int y, int a, int b, String couleur){
		if(testDeplacement()==true){
			if(((x+y)%2==0)){
				tab[x][y].setBackground(Color.black);
				p1.remove(Image);
			}
			else if(((x+y)%2==1)){
				tab[x][y].setBackground(color.geay);
				p1.remove(Image);
			}
			switch(couleur){
			case(PN){
				tab[a][b].setBackground(lab1);
			}
			case(PB){
				tab[a][b].setBackground(lab);
			}
			case(PB){
				tab[a][b].setBackground(lab);
			}
			}
		}
	}*/
	}}
	
	
	/*Main*/ 
	/*public static void main(String []args){
	Damier da=new Damier();
	da.pack();
	da.setVisible(true);
	}*/
	}
