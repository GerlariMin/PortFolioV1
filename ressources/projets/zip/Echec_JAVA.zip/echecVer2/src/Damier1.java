import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
/*import javax.swing.JLabel;*/
import javax.swing.JPanel;
	
public class Damier1 extends JFrame {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//tab[i][j] == pion[][] pla;//, pour actualiser regarder les mouvements possible et mouselistener
	
	private JPanel [][]tab=new JPanel[8][8];
	private Container cf=getContentPane();
	
	/*Constructeur*/ 
	public Damier1(pion[][] plat){
		setTitle("Echecs");
		
		Dimension ecran = Toolkit.getDefaultToolkit().getScreenSize();
        
        this.setPreferredSize(new Dimension(ecran.width, ecran.height));
        
        this.setVisible(true);
		cf.setLayout(new GridLayout(1,8));
		JPanel p1=new JPanel();
		p1.setSize(getPreferredSize());
        p1.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		/*Plateau*/
		p1.setLayout(new GridLayout(8,8,5,5));
		for(int i=0;i<=7;i++){
			for(int j=0;j<=7;j++){
				tab[i][j]=new JPanel(); //on indique quon creer un tab de Jpanel
				if(((i+j)%2)==0){ //si indice pair
					tab[i][j].setBackground(Color.black); //fond case noir
					p1.add(tab[i][j]); //on ajoute au panel p1 la case du tableau de panel
					System.out.println("casenoire: fait" +" " +i +" " +j);
				}
				
				else if(((i+j)%2)==1){ 
					tab[i][j].setBackground(Color.gray); //si indice impair on met en gris
					p1.add(tab[i][j]); 
					System.out.println("casegrise: fait" +" " +i +" " +j);
				}
				
				if(plat[i][j]!= null ){
					System.out.println("pi�ce trouv�e");
					System.out.println(plat[i][j].toString());
					if(plat[i][j].toString() =="TB"){
						JLabel lab3 = new JLabel(new ImageIcon("./src/tourb.png")); 
						lab3.setSize(getPreferredSize());
			            lab3.setVisible(true);
						tab[i][j].add(lab3);
						p1.add(tab[i][j]);
						cf.add(p1);
					//	System.out.println("lab3: fait" +" " +i +" " +j);
						
					}
					else if(plat[i][j].toString()=="TN"){
						JLabel lab3 = new JLabel(new ImageIcon("./src/touro.png")); 
						lab3.setSize(getPreferredSize());
			            lab3.setVisible(true);
						tab[i][j].add(lab3);
						p1.add(tab[i][j]);
						cf.add(p1);
						//System.out.println("lab3: fait" +" " +i +" " +j);
					}		
					else if(plat[i][j].toString() =="FB"){
						JLabel lab2 = new JLabel(new ImageIcon("./src/foub.png")); 
						lab2.setSize(getPreferredSize());
			            lab2.setVisible(true);
						tab[i][j].add(lab2);
						p1.add(tab[i][j]);
						cf.add(p1);
						//System.out.println("lab2: fait" +" " +i +" " +j);
					}
					else if(plat[i][j].toString()=="FN"){
						JLabel lab2 = new JLabel(new ImageIcon("./src/fouo.png")); 
						lab2.setSize(getPreferredSize());
			            lab2.setVisible(true);
						tab[i][j].add(lab2);
						p1.add(tab[i][j]);
						cf.add(p1);
				//		System.out.println("lab2: fait" +" " +i +" " +j);
					}
					else if(plat[i][j].toString() =="CB"){
						JLabel lab = new JLabel(new ImageIcon("./src/cavalierb.png")); 
						lab.setSize(getPreferredSize());
			            lab.setVisible(true);
						tab[i][j].add(lab);
						p1.add(tab[i][j]);
						cf.add(p1);
				//		System.out.println("lab: fait" +" " +i +" " +j);
					}
					else if(plat[i][j].toString()=="CN"){
						JLabel lab = new JLabel(new ImageIcon("./src/cavaliero.png"));
						lab.setSize(getPreferredSize());
			            lab.setVisible(true);
						tab[i][j].add(lab);
						p1.add(tab[i][j]);
						cf.add(p1);
					//	System.out.println("lab: fait" +" " +i +" " +j);
					}
					else if(plat[i][j].toString() =="PB"){
						JLabel lab1 = new JLabel(new ImageIcon("./src/pionb.png"));
						lab1.setSize(getPreferredSize());
			            lab1.setVisible(true);
						tab[i][j].add(lab1);
						p1.add(tab[i][j]);
						cf.add(p1);
					//	System.out.println("lab1: fait" +" " +i +" " +j);
					}
					else if(plat[i][j].toString()=="PN"){
						JLabel lab1 = new JLabel(new ImageIcon("./src/piono.png")); 
						lab1.setSize(getPreferredSize());
			            lab1.setVisible(true);
						tab[i][j].add(lab1);
						p1.add(tab[i][j]);
						cf.add(p1);
						//System.out.println("lab1: fait" +" " +i +" " +j);
					}
					else if(plat[i][j].toString() =="RoB"){
						JLabel lab5 = new JLabel(new ImageIcon("./src/roib.png"));
						lab5.setSize(getPreferredSize());
			            lab5.setVisible(true);
						tab[i][j].add(lab5);
						p1.add(tab[i][j]);
						cf.add(p1);
						//System.out.println("lab5: fait" +" " +i +" " +j);
					}
					else if(plat[i][j].toString()=="RoN"){
						JLabel lab5 = new JLabel(new ImageIcon("./src/roio.png")); 
						lab5.setSize(getPreferredSize());
			            lab5.setVisible(true);
						tab[i][j].add(lab5);
						p1.add(tab[i][j]);
						cf.add(p1);
						//System.out.println("lab5: fait" +" " +i +" " +j);
					}
					else if(plat[i][j].toString() =="ReB"){
						JLabel lab6 = new JLabel(new ImageIcon("./src/reineb.png")); 
						lab6.setSize(getPreferredSize());
			            lab6.setVisible(true);
						tab[i][j].add(lab6);
						p1.add(tab[i][j]);
						cf.add(p1);
					//	System.out.println("lab6: fait" +" " +i +" " +j);
					}
					else if(plat[i][j].toString()=="ReN"){
						//System.out.println("Reine Noir");
						JLabel lab6 = new JLabel(new ImageIcon("./src/reineo.png")); 
						lab6.setSize(getPreferredSize());
			            lab6.setVisible(true);
						tab[i][j].add(lab6);
						p1.add(tab[i][j]);
						cf.add(p1);
						//System.out.println("lab6: fait" +" " +i +" " +j);
					}
					
				
	
	
			cf.add(p1);
			//cf.setSize(getPreferredSize());
            cf.setVisible(true);

	/*Centrer la fenetre*/
			Dimension screenSize =Toolkit.getDefaultToolkit().getScreenSize();
			pack();
			setLocation((screenSize.width-getWidth())/2,(screenSize.height-getHeight())/2);
				}
			}
		}
	}
	
	
	/*Main*/ 
	
	}