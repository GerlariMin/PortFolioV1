
public class cavalier extends pion {
		
		public cavalier( boolean couleur)
		{
			super( couleur );
		}
		public boolean testDeplacement( int x, int y,int a,int b, pion plat[][])
		{
			if(( b-y == 2 || b-y == -2 )&&( a-x == 1 || a-x == -1 ))
			{
				if(plat[a][b] == null || plat[a][b].getcouleur() != couleur)
					return true;
			}
			if(( b-y == 1 || b-y == -1 )&&( a-x == 2 || a-x == -2 ))
			{
				if(plat[a][b] == null || plat[a][b].getcouleur() != couleur)
					return true;
			}
			return false;
		}
		public String toString()
		{
			if(couleur)
				return "CB";
			return "CN";
		}
}
