
public class fou extends pion {
	
	public fou( boolean couleur)
	{
		super( couleur );
	}
	public boolean testDeplacement( int x, int y,int a,int b, pion plat[][])
	{
		if(( plat[a][b] != null && plat[a][b].getcouleur() != couleur ) || plat[a][b] == null)
		{
			if( x-y == a-b )
			{
				if( a > x )
				{
					int xa = x+1;
					int yb = y+1;
					while( xa < a && yb < b)
					{
						if( plat[xa][yb] != null )
							return false;
						xa++;
						yb++;
					}
				}
				if( a < x )
				{
					int xa = a+1;
					int yb = b+1;
					while( xa < x && yb < y )
					{
						if(plat[xa][yb] != null)
							return false;
						xa++;
						yb++;
					}
				}
				return true;
			}
			if( x+y == a+b)
			{
				if( x < a )
				{
					int xa = x+1;
					int yb = y-1;
					while( xa < a && yb < b )
					{
						if( plat[xa][yb] != null)
							return false;
						xa++;
						yb-=1;
					}
				}
				if( x > a )
				{
					int xa = a+1;
					int yb = b-1;
					while( xa < x && yb > y )
					{
						if( plat[xa][yb] != null)
							return false;
						xa++;
						yb-=1;
					}
				}
				return true;
			}
		}
		return false;
	}
	public String toString()
	{
		if(couleur)
			return "FB";
		return "FN";
	}
}
