import java.util.*;

import javax.swing.JFrame;

public class jeu extends JFrame{
	
	public static void main (String[] args) {
		boolean tourJoueur = true ;
		plateau echecs = new plateau();
		Scanner sc = new Scanner(System.in);
		String req ;
		boolean tourfait = false;
		
		int t[] = new int[4];
		System.out.println("debut partie");
		while( !echecs.estmat(tourJoueur))
		{
			Damier1 da = new Damier1( echecs.get() );
			da.pack();
			da.setVisible(true);
			do
			{
				if(tourJoueur)
				{
					System.out.println(" d�placement du joueur des pions Blancs : ");
				}
				else
				{
					System.out.println(" d�placement du joueur des pions Noirs : ");
				}
				do{
					req = sc.nextLine();
				}while(req.length() != 2 || !echecs.testbordure(req.charAt(0)-96-1,req.charAt(1)-48-1) );
				t[0]=req.charAt(0)-97;
				t[1]=req.charAt(1)-48-1;
				System.out.println(" en :");
				do{
					req = sc.nextLine();
				}while(req.length() != 2 || !echecs.testbordure(req.charAt(0)-96-1,req.charAt(1)-48-1) );
				t[2]=req.charAt(0)-97;
				t[3]=req.charAt(1)-49;
				System.out.println("coordonn�es entr�es : x = "+t[0]+" / y = "+t[1]+" / a = "+t[2]+" / b = "+t[3]);
				echecs.promotion(echecs.get());
			}while(!echecs.deplacement(t[0], t[1], t[2], t[3], tourJoueur));
			
			tourJoueur = !tourJoueur;
		}
		sc.close();
		System.out.println("fin de partie");
	}

}
