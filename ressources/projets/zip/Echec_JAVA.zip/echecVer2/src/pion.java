
public class pion {
	private boolean premierDep; 
	protected boolean couleur;
	
	public boolean getcouleur()
	{
		return this.couleur;
	}
	
	public pion( boolean couleur) 
	{
		this.couleur = couleur;
		this.premierDep = true;
	}
	public boolean testDeplacement( int x, int y,int a,int b, pion plat[][])
	{
		if( couleur )
		{
			if(( x == a && b == y+2 && plat[a][y+1] == null &&(plat[a][b] == null || plat[a][b].getcouleur() == false )) && premierDep == true )
			{
				premierDep = false;
				return true;
			}
			if( x == a && b == y+1 && plat[a][b] == null )
			{
				return true;
			}
			if(( a == x+1 || a == x-1)&& b == y+1 && plat[a][b] != null && plat[a][b].getcouleur() == false)
			{
				if( plat[a][b].getcouleur() == false)
					return true;
			}
			return false;
		}
		else
		{
			if(( x == a && b == y-2 && plat[a][y-1] == null &&(plat[a][b] == null || plat[a][b].getcouleur() == true )) && premierDep == true )
			{
				premierDep = false;
				return true;
			}
			if( x == a && b == y-1 && plat[a][b] == null )
			{
				return true;
			}
			if(( a == x+1 || a == x-1)&& b == y-1 && plat[a][b] != null && plat[a][b].getcouleur() == true)
			{
				if( plat[a][b].getcouleur() == true)
					return true;
			}
			return false;
		}
	}
	public String toString()
	{
		if(couleur)
			return "PB";
		return "PN";
	}
}
