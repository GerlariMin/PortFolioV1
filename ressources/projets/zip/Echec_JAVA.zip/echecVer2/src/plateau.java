import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class plateau{
	private pion[][] plat;
	private int roiblancx;
	private int roiblancy;
	private int roinoirx;
	private int roinoiry;
	
	public plateau( String test )
	{
		plat = new pion[8][8];
		/*if( test == "pat1" )
		{	
			plat[0][2] = new cavalier(true);
			plat[2][0] = new fou(true);
			plat[3][0] = new reine(true);
			plat[4][0] = new roi(true);
			this.roiblancx = 4;
			this.roiblancy = 0;
			plat[1][4] = new fou(true);
			plat[6][0] = new cavalier(true);
			plat[7][0] = new tour(true);
			
				plat[0][3] = new pion(true);
				plat[1][1] = new pion(true);
				plat[2][1] = new pion(true);
				plat[3][1] = new pion(true);
				plat[4][3] = new pion(true);
				plat[5][1] = new pion(true);
				plat[6][1] = new pion(true);
				plat[7][1] = new pion(true);
			
				plat[0][4] = new pion(false);
				plat[1][6] = new pion(false);
				plat[2][6] = new pion(false);
				plat[3][4] = new pion(false);
				plat[4][4] = new pion(false);
				plat[5][6] = new pion(false);
				plat[6][6] = new pion(false);
				plat[7][6] = new pion(false);
			plat[0][7] = new tour(false);
			plat[1][7] = new cavalier(false);
			plat[2][7] = new fou(false);
			plat[3][7] = new reine(false);
			plat[4][7] = new roi(false);
			this.roinoirx = 4;
			this.roinoiry = 7;
			plat[6][7] = new cavalier(false);
			plat[7][7] = new tour(false);
		}*/
		if( test == "pat2")
		{
			roinoirx = 7;
			roinoiry = 7;
			roiblancx = 0;
			roiblancy = 0;
			plat[7][7] = new roi(false);
			plat[0][0] = new roi(true);
			plat[3][3] = new reine(true);
		}
		/*if( test == "pat3")
		{
			roinoirx = 0;
			roinoiry = 7;
			roiblancx = 1;
			roiblancy = 5;
			plat[0][7] = new roi(false);
			plat[1][5] = new roi(true);
			plat[0][5] = new cavalier(true);
			plat[4][3] = new fou(true);
		}
		if( test == "pat4")
		{
			roinoirx = 3;
			roinoiry = 7;
			roiblancx = 0;
			roiblancy = 0;
			plat[3][7] = new roi(false);
			plat[0][0] = new roi(true);
		}*/
	}
	public plateau()
	{
		this.plat = new pion[8][8];
		
		plat[0][0] = new tour(true);
		plat[1][0] = new cavalier(true);
		plat[2][0] = new fou(true);
		plat[3][0] = new reine(true);
		plat[4][0] = new roi(true);
		this.roiblancx = 4;
		this.roiblancy = 0;
		plat[5][0] = new fou(true);
		plat[6][0] = new cavalier(true);
		plat[7][0] = new tour(true);
		for(int j = 0; j < 8 ; j++)
		{
			plat[j][1] = new pion(true);
		}
		for(int j = 0; j < 8 ; j++) 
		{
			plat[j][6] = new pion(false);
		}
		plat[0][7] = new tour(false);
		plat[1][7] = new cavalier(false);
		plat[2][7] = new fou(false);
		plat[3][7] = new reine(false);
		plat[4][7] = new roi(false);
		this.roinoirx = 4;
		this.roinoiry = 7;
		plat[5][7] = new fou(false);
		plat[6][7] = new cavalier(false);
		plat[7][7] = new tour(false);
	}
	
	public pion[][] get()
	{
		return plat;
	}
	
	
	public boolean testbordure( int a,int b)
	{
		if( a > 7 || a < 0 || b > 7 || b < 0 )
			return false;
		return true;
	}
	public boolean deplacement(int x,int y,int a,int b, boolean couleur)
	{
		if(plat[x][y] != null && plat[x][y].getcouleur() == couleur)
		{
			System.out.println("coordonn�es depart possible");
			if(testbordure(a, b) == true && plat[x][y].testDeplacement(x, y, a, b, this.plat) )
			{
				System.out.println("deplacement en cours ");
				if( x == roiblancx && y == roiblancy)
				{
					roiblancx = a;
					roiblancy = b;
				}
				if( x == roinoirx && y == roinoiry)
				{
					roinoirx = a;
					roinoiry = b;
				}
				pion ech = plat[a][b];
				plat[a][b] = null;
				plat[a][b] = plat[x][y];
				plat[x][y] = null;
				System.out.println("test echec ...");
				if( this.estpat(couleur))
				{
					System.out.println("echec au roi");
					plat[x][y] = plat[a][b];
					plat[a][b] = ech;
					return false;
				}
				else if( couleur )
				{
					System.out.println("roi blanc en s�curit� ");
				}
				else
					System.out.println("roi noir en s�curit�");
				if( couleur && this.estpat(!couleur) )
				{
					System.out.println("roi noir en �chec ");
				}
				else if( !couleur && this.estpat(couleur) )
					System.out.println("roi blanc en �chec");
				return true;
			}
		}
		System.out.println(" commande impossible");
		return false;
	}
	
	public void promotion(pion[][] plat){ //si blanc ou noir et que ses coordonn�es se trouve a lautre bout du plateau on promu
		for(int j=0; j<=7; j++){
			if(plat[j][7] != null && plat[j][7].toString() == "PB" && j<=7){
			System.out.println("Veuillez choisir la pi�ce par laquelle vous voulez �changer votre pion blanc:");
			System.out.println("tour: 1");
			System.out.println("fou: 2");
			System.out.println("cavalier: 3");
			System.out.println("reine: 4");
			Scanner Sc = new Scanner( System.in);
			int num = Sc.nextInt();
			do{
			switch(num){ 
			case 1:
				plat[j][7] = new tour(true); // on met une tour d couleur blanche
				break;
			case 2: 
				plat[j][7] = new fou(true);
				break;
			case 3:
				plat[j][7] = new cavalier(true);
				break;
			case 4:
				plat[j][7] = new reine(true);
				break;
			default:
				System.out.println("Erreur");
				break;
			}

			}while( num < 1 || num > 4);
			Sc.close();
		}
		
		if(plat[j][0] != null && plat[j][0].toString() == "PN")
		{
			System.out.println("Veuillez choisir la pi�ce par laquelle vous voulez �changer votre pion noir:");
			System.out.println("tour: 1");
			System.out.println("fou: 2");
			System.out.println("cavalier: 3");
			System.out.println("reine: 4");
			Scanner sC = new Scanner( System.in);
			int num = sC.nextInt();
			do{
			switch(num){ 
			case 1:
				plat[j][0] = new tour(false); // on met une tour d couleur blanche
				break;
			case 2: 
				plat[j][0] = new fou(false);
				break;
			case 3:
				plat[j][0] = new cavalier(false);
				break;
			case 4:
				plat[j][0] = new reine(false);
				break;
			default:
				System.out.println("Erreur");
				break;
			}
	
			}while( num < 1 || num > 4);
			sC.close();
		}
			//les pions blancs sont tjrs en bas donc si il arrive a i=7 ya promotion
		}
	}
	
	public boolean estpat( boolean coul)
	{
		int x = 0;
		int y = 0;
		while( y < 8 )
		{
			if( plat[x][y] != null )
			{
				//System.out.println("pi�ce trouv�e : x = "+x+" / y = "+y+" || couleur = "+plat[x][y].getcouleur()+" // test roi noir : "+roinoirx+" / "+roinoiry+"  = "+ plat[x][y].testDeplacement(x, y, roinoirx, roinoiry, plat)+" // test roi blanc : "+roiblancx+" / "+roiblancy+"  = "+plat[x][y].testDeplacement(x, y, roiblancx, roiblancy, plat));
				if( plat[x][y].getcouleur() != coul && plat[x][y].testDeplacement(x, y, roiblancx, roiblancy, plat))
				{
					return true;
				}
				if( plat[x][y].getcouleur() != coul && plat[x][y].testDeplacement(x, y, roinoirx, roinoiry, plat))
				{
					return true;
				}
			}
			x++;
			if( x == 8 )
			{
				x = 0;
				y += 1;
			}
		}
		return false;
	}
	public boolean estmat( boolean coul )
	{
		int x = 0;
		int y = 0;
		int a = 0;
		int b = 0;
		pion ech;
		
		boolean pat = this.estpat( coul );
		//System.out.println("test pat : "+pat);
		
		while( y < 8 && pat )
		{
			if( plat[x][y] != null && plat[x][y].getcouleur() == coul )
			{
				//System.out.println(" pion de couleur "+coul+" trouv� � : x = "+x+" / y = "+y);
				while( b < 8 && pat)
				{
					if( plat[x][y].testDeplacement(x, y, a, b, plat ))
					{
						//System.out.println("   coordonn�es trouv�es : a = "+a+" / b = "+b);
						if( x == roinoirx && y == roinoiry )
						{
							roinoirx = a;
							roinoiry = b;
							
							ech = plat[a][b];
							plat[a][b] = plat[x][y];
							plat[x][y] = null;
							pat = this.estpat(coul);
							plat[x][y] = plat[a][b];
							plat[a][b] = ech;
							
							roinoirx = x;
							roinoiry = y;
						}
						else if( x == roiblancx && y == roiblancy )
						{
							roiblancx = a;
							roiblancy = b;
							
							ech = plat[a][b];
							plat[a][b] = plat[x][y];
							plat[x][y] = null;
							pat = this.estpat(coul);
							plat[x][y] = plat[a][b];
							plat[a][b] = ech;
							
							roiblancx = x;
							roiblancy = y;
						}
						else
						{
							ech = plat[a][b];
							plat[a][b] = plat[x][y];
							plat[x][y] = null;
							pat = this.estpat(coul);
							plat[x][y] = plat[a][b];
							plat[a][b] = ech;
						}
						
					/*	if( !pat)
						{
							System.out.println("il n'y a pas Mat. coordonn�es : x = "+x+" / y = "+y+" / a = "+a+" / b = "+b);
						}*/
					}
					a++;
					if( a == 8 )
					{
						a = 0;
						b+=1;
					}
				}
				a = 0;
				b = 0;
			}
			x++;
			if( x == 8 )
			{
				x = 0;
				y+=1;
			}
		}
		if( pat )
		{
			if( !coul)
				System.out.println(" joueur 1 a gagn�");
			else
				System.out.println(" joueur 2 a gagn�");
			System.exit(0);
			return true;
		}
		else
			return false;
			
				
	}
	public void load()
	{
		int x = 0;
		int y = 0;
		pion p = null;
		String v ;
		try{
			FileReader fch = new FileReader( "sauvegarde" );
			BufferedReader bch = new BufferedReader( fch );
			String line = bch.readLine();
			
			
			while(line != null)
			{
				
				StringTokenizer st = new StringTokenizer( line, "\t");
				v = new String(st.nextToken());
				if( v == "RoB")
					p = new roi(true);
				if( v == "RoN")
					p = new roi(false);
				if( v == "PN")
					p = new pion(false);
				if( v == "PB")
					p = new pion(true);
				if( v == "CB")
					p = new cavalier(true);
				if( v == "CN")
					p = new cavalier(false);
				if( v == "TB")
					p = new tour(true);
				if( v == "TN")
					p = new tour(false);
				if( v == "FB")
					p = new fou(true);
				if( v == "FN")
					p = new fou(false);
				if( v == "ReN")
					p = new reine(false);
				if( v == "ReB")
					p = new reine(true);
				plat[Integer.parseInt(st.nextToken())][Integer.parseInt(st.nextToken())] = p;
				
			}
		}catch( IOException e){ System.err.println(e);}
	}
	public void save()
	{
		int y = 0;
		int x = 0;
		
		try{
			FileWriter fch = new FileWriter( "sauvegarde" );
			BufferedWriter bch = new BufferedWriter( fch );
			while( y < 8)
			{
				if( plat[x][y] != null)
					fch.write(plat[x][y].toString()+"\t"+Integer.toString(x)+"\t"+Integer.toString(y)+"\t");
				x++;
				if(x == 8)
				{
					x = 0;
					y+=1;
				}
			}
		}catch( IOException e){ System.err.println(e);}
	}
}