
public class reine extends pion {
		
	public reine( boolean couleur)
	{
		super( couleur );
	}
	public boolean testDeplacement( int x, int y,int a,int b, pion plat[][])
	{
		if(( plat[a][b] != null && plat[a][b].getcouleur() != couleur ) || plat[a][b] == null)
		{
			if( x-y == a-b )
			{
				if( a > x )
				{
					int xa = x+1;
					int yb = y+1;
					while( xa < a && yb < b)
					{
						if( plat[xa][yb] != null )
							return false;
						xa++;
						yb++;
					}
				}
				if( a < x )
				{
					int xa = a+1;
					int yb = b+1;
					while( xa < x && yb < y )
					{
						if(plat[xa][yb] != null)
							return false;
						xa++;
						yb++;
					}
				}
				return true;
			}
			if( x+y == a+b)
			{
				if( x < a )
				{
					int xa = x+1;
					int yb = y-1;
					while( xa < a && yb < b )
					{
						if( plat[xa][yb] != null)
							return false;
						xa++;
						yb-=1;
					}
				}
				if( x > a )
				{
					int xa = a+1;
					int yb = b-1;
					while( xa < x && yb > y )
					{
						if( plat[xa][yb] != null)
							return false;
						xa++;
						yb-=1;
					}
				}
				return true;
			}
		}
		if( (x == a || y == b)&& b >=0 && b <= 7 && a >= 0 && b <=7 )
		{
			if(( plat[a][b] != null && plat[a][b].getcouleur() != couleur ) || plat[a][b] == null)
			{
				if( a > x )
				{
					for( int xd = x+1 ; xd < a ; xd++ )
					{
						if( plat[xd][y] != null)
							return false;
					}
				}
				else if( a < x )
				{
					for( int xg = a; xg < x ; xg++)
					{
						if( plat[xg][y] != null )
							return false;
					}
				}
				if( b > y)
				{
					for( int yh = y+1 ; yh < b ; yh++ )
					{
						if( plat[x][yh] != null)
							return false;
					}
				}
				else if( b < y)
				{
					for( int yb = b ; yb < y ; yb++ )
					{
						if( plat[x][yb] != null)
							return false;
					}
				}
				return true;
			}
		}
		return false;
	}
	public String toString()
	{
		if(couleur)
			return "ReB";
		return "ReN";
	}
}
