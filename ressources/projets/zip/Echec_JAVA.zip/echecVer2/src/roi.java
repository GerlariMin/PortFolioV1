
public class roi extends pion {
		
	public roi( boolean couleur)
	{
		super( couleur );
	}
	public boolean testDeplacement( int x, int y,int a,int b, pion plat[][])
	{
		if(( a == x+1 || a == x || a == x-1 ) && ( b == y+1 || b == y || b == y-1 ) && ( b != y || a != x))
		{
			if(plat[a][b] == null || (plat[a][b]!= null && plat[a][b].getcouleur() != couleur))
			//	System.out.println(" Test roi "+this.getcouleur()+" : a = "+a+" / b = "+b+" / resultat valide ");
				return true;
		}
		//System.out.println(" Test roi "+this.getcouleur()+" : a = "+a+" / b = "+b+" / resultat non valide ");
		return false;
	}
	public String toString()
	{
		if(couleur)
			return "RoB";
		return "RoN";
	}
}
