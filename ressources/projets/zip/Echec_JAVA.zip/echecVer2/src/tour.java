public class tour extends pion {
	
	public tour( boolean couleur)
	{
		super( couleur );
	}
	public boolean testDeplacement( int x, int y,int a,int b, pion plat[][])
	{
		if (x == a || y == b)
		{
			if(( plat[a][b] != null && plat[a][b].getcouleur() != couleur ) || plat[a][b] == null)
			{
				if( a > x )
				{
					for( int xd = x+1 ; xd < a ; xd++ )
					{
						if( plat[xd][y] != null)
							return false;
					}
				}
				else if( a < x )
				{
					for( int xg = a+1; xg < x ; xg++)
					{
						if( plat[xg][y] != null )
							return false;
					}
				}
				if( b > y)
				{
					for( int yh = y+1 ; yh < b ; yh++ )
					{
						if( plat[x][yh] != null)
							return false;
					}
				}
				else if( b < y)
				{
					for( int yb = b+1 ; yb < y ; yb++ )
					{
						if( plat[x][yb] != null)
							return false;
					}
				}
				return true;
			}
		}
		return false;

	}
	public String toString()
	{
		if(couleur)
			return "TB";
		return "TN";
	}
}