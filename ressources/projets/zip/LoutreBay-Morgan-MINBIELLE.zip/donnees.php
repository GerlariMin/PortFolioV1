<?php

	header("Content-type: application/json; charset=utf-8");
	header("Cache-Control: no-cache, must-revalidate");
	
	include("model.php");
	$m = Model::get_model();
	
	switch($_GET['fonction']){
		case 'chercher':
			error_log("donnees.php chercher");
			$get = $m->get_loutres();
			echo json_encode($get);
			break;
		
		case 'uneloutre':
			error_log("donnees.php uneloutre");
			$getOne = $m->get_one_loutre($_GET['i']);
			echo json_encode($getOne);
			break;
			
		case 'carroussel':
			error_log("donnees.php carroussel");
			$getCar = $m->get_carroussel($_GET['index']);
			echo json_encode($getCar);
			break;
			
		case 'supprimer_vente':
			error_log("donnees.php supprimer_vente");
			$supp = $m->delete_vente($_GET['index']);
			echo json_encode($supp);
			break;
		
		case 'sort_prix':	
			error_log("donnees.php sort_prix");
			$sortp = $m->sort_prix($_GET['modulo']);
			
			echo json_encode($sortp);
			break;
			
		case 'sort_race':	
			error_log("donnees.php sort_race");
			$sortp = $m->sort_race($_GET['modulo']);
			
			echo json_encode($sortp);
			break;
		
		default:
			error_log("donnees.php default");
			return "Erreur";
			break;
	}
		
?>
