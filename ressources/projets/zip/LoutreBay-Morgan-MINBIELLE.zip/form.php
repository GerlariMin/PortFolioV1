<?php
	error_log("MODEL.PHP");
	function base64_encode_image ($filename=string/*,$filetype=string*/) {
		error_log("form.php base64");
		if ($filename) {
			$imgbinary = fread(fopen($filename, "r"), filesize($filename));
			
			return /*'data:image/' . $filetype . ';base64,' . */base64_encode($imgbinary);
		}
	}
	
	include("model.php");
	$m = Model::get_model();
	
	switch($_GET['fonction']){
		
		case 'ajout':
			error_log("form.php ajout ".$_SESSION['login']);
			/*$add = $m->add_loutre($_POST['race'], $_SESSION['id'], $_POST['taille'], $_POST['poids'], $_POST['nom'], $_POST['prix'], $_POST['description'], base64_encode_image($_POST['image'])); 
			echo json_encode($add);*/
			var_dump($_POST);
			break;
			
		case 'connexion':
			error_log("form.php connexion");
			$conx=$m->get_one_user($_POST['login'], $_POST['password']);
			$_SESSION['login'] ="";
			$_SESSION['id'] =0;
			$_SESSION['login'] = $conx['login'];
			$_SESSION['id'] = $conx['id'];
			echo json_encode($conx);
			break;
			
		case 'inscription':
			error_log("form.php inscription");
			$insc=$m->inscription($_POST['login'], $_POST['nom'], $_POST['prenom'], $_POST['mail'], $_POST['password'], $_POST['cpassword']);
			echo json_encode($insc);
			break;
			
		case 'liste_ventes':
			$droit=$m->droit($_SESSION['login']);
			if($droit['is_admin']==true){
				error_log("vrai");
				$ventes=$m->get_all_ventes();
			}else{
				error_log("faux");
				$ventes=$m->get_my_ventes($_SESSION['id'], $_SESSION['login']);
			}
			echo json_encode($ventes);
			break;
			
		case 'modifier_vente':
			error_log("form.php modifier_vente");
			
			$edit = $m->edit_vente($_GET['id'], $_POST['race'], $_POST['taille'], $_POST['poids'], $_POST['nom'], $_POST['prix'], $_POST['description']/*, base64_encode_image($_POST['image'])*/);
			
			echo json_encode($edit);
			break;
			
		case 'verif_login':
			error_log("forme.php verif_login");
			$log=$m->verif_login($_POST['login']);
			echo json_encode($log);
			break;
		
		default:
			error_log("form.php default ");
			$add = $m->add_loutre($_POST['race'], $_SESSION['id'], $_POST['taille'], $_POST['poids'], $_POST['nom'], $_POST['prix'], $_POST['description'], base64_encode_image($_POST['image'])); 
			header('Location: index.php');
			break;
	}

?>
