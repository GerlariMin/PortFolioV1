var i = 0;
var cpt = 0;
var cpt_prix = 0;
//créé untoken (quiest un loalstorage) qui est unechainedecaractere aleatoire de 32 caracteres qui sera stockée dans la bdd 
// token créé si on coche rester connecter 
// quand on clique sur deconnexion on vide le localstorage

function carroussel(){
	console.log("index.js carroussel");
	console.log("index: " +i);
	
	$.get("template.html", function(rep){
				
				car = $(rep).filter("#Carroussel").html();
				console.log("index: " +i);
				
				$.get("donnees.php", {fonction: "carroussel", index: i}, function(reponse){
				
					reponse[0]['first']=true; //pour ajouter la classe active a la premiere image du carroussel
					//reponse['first']=true;
					car = Mustache.render(car, reponse);
					
					//$("#container").append(car);
					$("#imgcarroussel").html(car);
					
				});
				
	}, "html");
	
}

function connexion(){
	console.log("index.js connexion");
	
	var form = $('#formConnexion').serialize();
	
	$.post("form.php?fonction=connexion", form, function(reponse){
		
		console.log("reponse: " + reponse + " : " + reponse['login']);
		
		switch(reponse){
			
			case('false'):
				
				console.log("index.js false");
			
				$.get("template.html", function(rep){
					
					alerte = $(rep).filter("#Alerte").html();
					
					var message = {'type': 'danger', 'titre': 'Oops', 'message': 'Il semblerait que le compte demandé n\'existe pas!'};
					
					alerte = Mustache.render(alerte, message);
					
					$("#card-footer").html(alerte);
				}, "html");
				
				break;
			
			default:
			
				console.log("index.js default")
			
				$.get("template.html", function(rep){
					
					alerte = $(rep).filter("#Alerte").html();
					
					var message = {'type': 'success', 'titre': 'Succès', 'message': 'La connexion à votre compte est établie!', 'accueil' : true};
					
					alerte = Mustache.render(alerte, message);
					
					$("#card-footer").html(alerte);
					
					sessionStorage.setItem("login", reponse['login']);
					console.log("session: "+sessionStorage.getItem("login"));
					
					
				}, "html");
			
				break;
		}
		
	}, "json");
}

function deconnexion(){
	sessionStorage.clear();
}

function inscription(){
	console.log("index.js inscription()");
	
	var iform = $('#form-inscription').serialize();
	
	$.post("form.php?fonction=inscription", iform, function(reponse){
		
		switch(reponse){
			
			case('false'):
			
				console.log("index.js inscription() falsee");
			
				$.get("template.html", function(rep){
					
					alerte = $(rep).filter("#Alerte").html();
					
					var message = {'type': 'danger', 'titre': 'Oops', 'message': 'Votre mot de passe et la confirmation de mot de passe ne correspondent pas!'};
					
					alerte = Mustache.render(alerte, message);
					
					$("#card-footer").html(alerte);
					
				}, "html");
				
				break;
			
			
			default:
			
				console.log("index.js inscription() default");
			
				$.get("template.html", function(rep){
					
					alerte = $(rep).filter("#Alerte").html();
					var message = {'type': 'success', 'titre': 'Succès', 'message': 'L\'inscription est terminée!', 'accueil' : true};
					alerte = Mustache.render(alerte, message);
					$("#card-footer").html(alerte);
					
					sessionStorage.setItem("login", reponse['login']);
					
				}, "html");
			
				break;
		}
		
	}, "json");
}

function loutre(){
	console.log("index.js loutre()");
	
	var hash=window.location.hash;
	
	switch(hash){
		
		case("#add"):
			console.log("index.js #add");
		
			$.get("template.html", function(rep){
				
				content = $(rep).filter("#add").html();
				
				$("#container").html(content);
		
			}, "html");
			break;
			
		case("#connexion"):
			console.log("index.js #connexion");
		
			$.get("template.html", function(rep){
				
				content = $(rep).filter("#Connexion").html();
				
				$("#container").html(content);
				
				$('#ilogin').keyup(function(){
					verif_login();
				});
		
			}, "html");
			break;
			
		case("#deconnexion"):
			console.log("index.js #deconnexion");
			
			sessionStorage.clear();
		
			window.location.hash="#home";
			
			break;
			
		case("#mesventes"):
			console.log("index.js #mesventes");
		
			$.get("template.html", function(rep){
				
				content = $(rep).filter("#Mesventes").html();
				
				$.get("form.php", {fonction: "liste_ventes"}, function(reponse){
					console.log("reponse: " + reponse);
					
					content = Mustache.render(content, reponse);
					
					$("#container").html(content);
					
				}, "json");
			}, "html");
			break;
			
		case('#modifier'):
			console.log("index.js modifier i: "+i);
			
			$.get("template.html", function(rep){
				
				content = $(rep).filter("#Modifier").html();
				
				$.get("donnees.php", {fonction: "uneloutre", i: i}, function(reponse){
					
					content = Mustache.render(content, reponse);
				
					$("#container").html(content);
					
				}, "json");
		
			}, "html");
			
			break;
			
		case('#supprimer'):
			console.log("index.js supprimer i: "+i);
			
			$.get("donnees.php", {fonction: "supprimer_vente", index: i}, function(){
				
				window.location.hash="#mesventes";
					
			}, "json");
		
			break;
			
		case("#uneLoutre"):
			console.log("index.js #uneloutre");
			
			$.get("template.html", function(rep){
				
				content = $(rep).filter("#Loutre").html();
				
				$.get("donnees.php", {fonction: "uneloutre", i: (i)}, function(reponse){
					
					content = Mustache.render(content, reponse);
					
					$("#container").html(content);
					
					carroussel();
					
				});
			}, "html");
			break;		
			
		default:
			console.log("index.js default");
			
			$.get("template.html", function(rep){
				
				content = $(rep).filter("#Liste").html();
				
				$.get("donnees.php", {fonction: "chercher"}, function(reponse){
					
					content = Mustache.render(content, reponse);
					$("#container").html(content);
					
					//carroussel();
				}, "json");
				
			}, "html");
			
			break;
	
	}
}

function modifier_vente(id){
	console.log("index.js modifier_vente id="+id);
	
	var eform = $('#form-edit').serialize();
	
	$.post("form.php?fonction=modifier_vente&id="+id, eform, function(reponse){
		window.location.hash="#mesventes";
	}, "json");

}

function progression(par){
	console.log("Par: " + par);
	var t=0;
	if(par!="" || par!=0){
		console.log("+");
		cpt++;
		t=(cpt*20);
		$("#progressbar").width(t+"%");
		$("#progressbar").val(t+"%");
		$("#progressbar").text("Progression: "+t+"%");
	} else{
		console.log("-");
		cpt--;
		t=(cpt*20);
		$("#progressbar").width(t+"%");
		$("#progressbar").val(t+"%");
		$("#progressbar").text("Progression: "+t+"%");
	}
	if(t<100){
		console.log("-de100");
		$("#vendre").fadeOut(500);
		$('#err_progress').fadeIn(500);
	}else{
		console.log("100+");
		$("#vendre").fadeIn(500);
		$('#err_progress').fadeOut(500);
	}
}

function sort_prix(){
	console.log("index.js sort_prix()");
		
		cpt_prix++;
		var mod = (cpt_prix%2);
			
			$.get("template.html", function(rep){
				
				content = $(rep).filter("#Liste").html();
				
				$.get("donnees.php", {fonction: "sort_prix", modulo: mod}, function(reponse){
					
					content = Mustache.render(content, reponse);
					$("#container").html(content);
					
					carroussel();
				}, "json");
				
			}, "html");
}



function sort_race(){
	console.log("index.js sort_prix()");
		
		cpt_prix++;
		var mod = (cpt_prix%2);
			
			$.get("template.html", function(rep){
				
				content = $(rep).filter("#Liste").html();
				
				$.get("donnees.php", {fonction: "sort_race", modulo: mod}, function(reponse){
					
					content = Mustache.render(content, reponse);
					$("#container").html(content);
					
					carroussel();
				}, "json");
				
			}, "html");
}

function verif_login(){
	console.log("index.js verif_login()");
	
	$.post("form.php?fonction=verif_login", {login: $('#ilogin').val()}, function(reponse){
		
		switch(reponse){
			
			case 'false':
				
				$('#login-addon1').removeClass("bg-warning");
				$('#errorlog').fadeOut(500);
				$('#ivalider').fadeIn(500);
				
				break;
				
			default: 
			
				$('#login-addon1').addClass("bg-warning");
				$('#errorlog').fadeIn(500);
				$('#ivalider').fadeOut(500);
				
				break;
				
		}
		  
	});
}

function verif_session(){
	
	if(sessionStorage.getItem("login")){
		
		$('#aconx').fadeOut(500);
		$('#avente').fadeIn(500);
		$('#deconnexion').fadeIn(500);
		$('#mesventes').fadeIn(500);
		
	}else {
		
		$('#aconx').fadeIn(500);
		$('#avente').fadeOut(500);
		$('#deconnexion').fadeOut(500);
		$('#mesventes').fadeOut(500);
		
	}
}

$(document).ready(function(){
	console.log("index.js document ready");
	
	verif_session()
	loutre();
	
	$(window).on("hashchange", function(){
		verif_session();
		loutre();
	});
});
