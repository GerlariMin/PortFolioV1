

<!DOCTYPE html>

<html lang="fr" class="h-100 w-100">
	
	<head>
		
		<meta charset="utf-8">
		
		<script src="jquery.js"></script>
		
		<script src="bootstrap-4.3.1-dist/js/bootstrap.js"></script>
		<link rel="stylesheet" href="bootstrap-4.3.1-dist/css/bootstrap.css">
		
		<script src="mustache.js-master/mustache.js"></script>
		
		<script src="index.js"></script>
		
		<script src="https://kit.fontawesome.com/d43c869f70.js"></script>		
		
		<link rel="icon" href="lico.jpg"/>
		
		<title> LoutreBay </title>
		
	</head>
	
	<body class="h-100" style="font-size: xx-large; font-family: Avantgarde, TeX Gyre Adventor, URW Gothic L, sans-serif">
	
		<div class="card rounded-lg h-100">
			
			<div class="card-header bg-dark">
				
				<nav class="navbar navbar-expand-lg navbar-dark bg-secodary">
						
					<a href="#Liste" class="navbar-brand text-decoration-none text-white">
								<i class="fas fa-compass"></i> <b>Loutr</b><b style="color: red;">e</b><b style="color: blue;">B</b><b style="color: yellow;">a</b><b style="color: green;">y</b>
					</a>
				
					<button id="btnnvb" class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
						
					<div class="collapse navbar-collapse" id="navbarNavDropdown">
						<ul class="navbar-nav">
							<!--<li class="nav-item active mr-1">
								<a href="#Liste" class="navbar-link text-decoration-none text-white">
									<i class="fas fa-compass"></i> Loutr<b style="color: red;">e</b><b style="color: blue;">B</b><b style="color: yellow;">a</b><b style="color: green;">y</b>
								</a>
							</li>-->
							<li class="nav-item mr-1">
								<a href="#add" class="navbar-link text-decoration-none text-white" id="avente" style="display: none;"> 
									<i class="fas fa-coins"></i> Vendre
								</a>
							</li>
							<li class="nav-item mr-1">
								<a href="#mesventes" class="navbar-link text-decoration-none text-white" id="mesventes" style="display: none;"> 
									<i class="fas fa-tasks"></i> Voir mes ventes
								</a>
							</li>
							<li class="nav-item mr-1">
								<a href="#connexion" class="navbar-link text-decoration-none text-white" id="aconx"> 
									<i class="fas fa-sign-in-alt"></i> Connexion
								</a>
							</li>
							<li class="nav-item mr-1">
								<a href="#deconnexion" class="navbar-item text-decoration-none text-white" id="deconnexion" style="display: none;"> 
									<i class="fas fa-power-off"></i> Déconnexion
								</a>
							</li>
						</ul>
					</div>
					
				</nav>
				
			</div>
			
			<div class="card-body bg-secondary" id="container">
				
			</div>
			
			<div class="card-footer bg-dark">
			
				<center>
					<p class="text-white">© 2019 Copyright: <a href="https://monportfolio-mm.000webhostapp.com/#contact" class="text-decoration-none">MINBIELLE Morgan</a> - 
						
						<a href="#Liste" class="text-decoration-none text-body">
							
							<b class="text-white">Loutr</b><b style="color: red;">e</b><b style="color: blue;">B</b><b style="color: yellow;">a</b><b style="color: green;">y</b>
							
						</a>
					</p>
				</center>
			
			</div>
			
		</div>
		
	</body>
	
</html>
