var listeloutre = [
	{
		"nom": "Loutre1",
		"race": "Loutre brune",
		"prix": "100€",
		"taille": "65cm",
		"description": "Loutre brune classique."
	}, {
		"nom": "Loutre2",
		"race": "Loutre blonde",
		"prix": "90€",
		"taille": "50cm",
		"description": "Loutre blonde classique."
	}, {
		"nom": "Loutre3",
		"race": "Loutre dorée",
		"prix": "200€",
		"taille": "80cm"
		"description": "Loutre guerrière shiny."
	}
]
