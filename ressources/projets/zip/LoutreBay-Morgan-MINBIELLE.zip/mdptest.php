<?php
	/*$var = password_hash("root", PASSWORD_BCRYPT);
	echo $var;*/
	
	if(password_verify("root", "$2y$10\$q/SoFBFUxWISpcjoWOyHpOxW6pb.QIQRqgJ.bH1Ol22IS3k5JBn.K")==true){echo "\n true";}else{echo "\n false";}
	
	$cpt=3;
	$ccpt=1;
	
	echo "modulo: ". ($cpt%2) . " : " . ($ccpt%2);
	echo "cpt" . $cpt;
	$cpt++;
	echo "cpt" . $cpt;
	
?>
