<?php
		session_start();
	
	
class Model {
	
	private static $instance = null;

	/* Connexion à la base de données*/
    private function __construct(){
		error_log("model.php __construct");

		try{
			$this->pdo = new PDO('mysql:host=localhost;dbname=test','','');
		}catch(PDOException $e){
			$erreur = 'Connexion échouée: '. $e->getMessage();
			return $erreur;
		}

    }

	/* Création d'un objet Model pour pouvoir utiliser lesdifférentes fonctions*/
    public static function get_model(){
		error_log("model.php get_model");

        if(is_null(self::$instance)){
			
            self::$instance = new Model();
            
        }
        
        return self::$instance;
    }
    
    public function add_image($img1, $img2, $img3, $img4){
		try{
			
			$req = $this->pdo->prepare("INSERT INTO images_loutre VALUES (NULL, :img1, :img2, :img3, :img4);");
			$req->execute(["img1" => $img1, "img2" => $img2, "img3" => $img3, "img4" => $img4]);

			$id_ajout = $this->pdo->prepare("SELECT LAST_INSERT_ID() FROM images_loutre;");
			$id_ajout->execute();
			
			return $id_ajout->fetch(PDO::FETCH_NUM);
			
		}catch(PDOException $e){
			
			$erreur = "Problème lors de l'ajout d'une loutre: " . $e->getMessage();
			
			return $erreur;
			
		}
	}
	
	/* Ajout des informations d'une loutre pour effectuer une vente*/
    public function add_loutre($race, $id_user, $taille, $poids, $nom, $prix, $description, $img){
		error_log("model.php add_loutre");
		
		try{
			$addimg = $this->add_image($img, null, null, null);
			$id_img = $addimg[0];
			
			$req = $this->pdo->prepare("INSERT INTO loutre_a_vendre VALUES (NULL, :race, :id_user, :id_img, :taille, :poids, :nom, :prix, :description, :img);");
			$req->execute(["race" => $race, "id_user" => $id_user, "id_img" => $id_img, "taille" => $taille, "poids" => $poids, "nom" => $nom, "prix" => $prix, "description" => $description, "img" => $img]);

		}catch(PDOException $e){
			
			$erreur = "Problème lors de l'ajout d'une loutre: " . $e->getMessage();
			
			return $erreur;
			
		}
		
    }
    
    public function delete_vente($index){
		error_log("model.php delete_vente");
		
		try{
			
			$req = $this->pdo->prepare("DELETE FROM loutre_a_vendre WHERE id = :index; ALTER TABLE loutre_a_vendre AUTO_INCREMENT =0;");
			$req->execute(["index" => $index]);
			
			return $req;
			
		} catch(PDOException $e){
			
			$erreur = "Problème lors de la suppression d'une vente: " . $e->getMessage();
			return $erreur;
			
		}
	}

	public function edit_vente($index, $race, $taille, $poids, $nom, $prix, $description/*, $image*/){
		error_log("model.php edit_vente");
		error_log("index".$index."race".$race."taille".$taille."poids".$poids."nom".$nom."prix".$prix."desc".$description/*."img".$image*/);
		try{
			/*$chaine="";
			if(!empty($race)){
				$chaine+= " id_race=".$race;
			}
			if(!empty($taille)){
				$chaine+= " taille=".$taille;
			}
			if(!empty($poids)){
				$chaine+= " poids=".$poids;
			}
			if(!empty($nom)){
				$chaine+= " nom=".$nom;
			}
			if(!empty($prix)){
				$chaine+= " prix=".$prix;
			}
			if(!empty($description)){
				$chaine+= " description=".$description;
			}*/
			/*if(!empty($image)){
				$chaine+= " image=".$image;
			}*/

			$req = $this->pdo->prepare("UPDATE loutre_a_vendre SET id_race =:race, taille = :taille, poids = :poids, nom_loutre = :nom, prix = :prix, description = :description WHERE id = :index;");
			$req->execute(["race" => $race, "taille" => $taille, "poids" => $poids, "nom" => $nom, "prix" => $prix, "description" => $description, "index" => $index]);
			
			return $req;
			
		} catch(PDOException $e){
			
			$erreur = "Problème lors de la suppression d'une vente: " . $e->getMessage();
			return $erreur;
			
		}
	}
    
    public function droit($login){
		error_log("model.php droit");
		
		$req = $this->pdo->prepare("SELECT is_admin FROM users WHERE login = :login;");
		$req->execute(["login" => $login]);
		$retour= $req->fetch(PDO::FETCH_ASSOC);
		
		return $retour;
	}
    
    /* Création d'un carroussel avec la première image de chaque loutre*/
    public function get_carroussel($index){
		error_log("model.php get_carroussel");
		
		$req = $this->pdo->prepare("SELECT image, nom_loutre FROM loutre_a_vendre where id = :index;");
		$req->execute(["index" => $index]);
		$tabat = $req->fetchAll(PDO::FETCH_ASSOC);
	
		return $tabat;
    }

	/* Récupération de toutes les loutres*/
    public function get_loutres(){
		error_log("model.php get_loutres");
		
		$req = $this->pdo->prepare("SELECT loutre_a_vendre.id, loutre_a_vendre.nom_loutre, loutre_a_vendre.prix, race_loutre.race FROM loutre_a_vendre, race_loutre where race_loutre.id=loutre_a_vendre.id_race ORDER BY loutre_a_vendre.id;");
		$req->execute();
		$t = $req->fetchAll(PDO::FETCH_ASSOC);
	
		return $t;
    }
    
    /* Récupération d'une loutre grâce à son ID*/
    public function get_one_loutre($index){
		error_log("model.php get_one_loutre");
		
		$req = $this->pdo->prepare("SELECT loutre_a_vendre.id, loutre_a_vendre.nom_loutre, race_loutre.race, loutre_a_vendre.taille, loutre_a_vendre.poids, race_loutre.region, loutre_a_vendre.prix, loutre_a_vendre.image, loutre_a_vendre.description, users.login, users.mail FROM loutre_a_vendre, race_loutre, users WHERE loutre_a_vendre.id_race = race_loutre.id AND users.id = loutre_a_vendre.id_user AND loutre_a_vendre.id=?;");
		$req->execute([$index]);
		$tab = $req->fetch(PDO::FETCH_ASSOC);
	
		return $tab;
    }  
    
    /* Récupération de toutes les ventes de loutres*/
	public function get_all_ventes(){
		error_log("model.php get_all_ventes");
		
		$req = $this->pdo->prepare("SELECT DISTINCT loutre_a_vendre.id, nom_loutre, login FROM loutre_a_vendre, users WHERE loutre_a_vendre.id_user = users.id;");
		$req->execute();
		$tab = $req->fetchAll(PDO::FETCH_ASSOC);
	
		return $tab;
	}
	
	/* Récupération de toutes les ventes d'une personne*/
	public function get_my_ventes($id, $login){
		error_log("model.php get_my_ventes");
		error_log("id: " .$id." login: ".$login); 
		$req = $this->pdo->prepare("SELECT loutre_a_vendre.id, loutre_a_vendre.nom_loutre, login FROM loutre_a_vendre, users WHERE loutre_a_vendre.id_user = :id AND users.login = :login;");
		$req->execute(["id" => $id, "login" => $login]);
		$tab = $req->fetch(PDO::FETCH_ASSOC);
	
		return $tab;
	}
    
    /* Récupérations des informations essentielles d'un utilisateur lors de la connexion*/
    public function get_one_user($login, $password){
		error_log("model.php get_one_user");
		
		try{

			$pswd = $this->pdo->prepare("SELECT password FROM users WHERE login = :login OR mail = :login;");
			$pswd->execute(["login" => $login]);
			$verif = $pswd->fetch(PDO::FETCH_ASSOC);
			
			$test=$verif['password'];

			if(password_verify($password, $test)==true){
				error_log("même mdp");
				$req = $this->pdo->prepare("SELECT id, login, nom, prenom, mail FROM users WHERE (login = :login OR mail = :login);");
				$req->execute(["login" => $login, "password" => $password]);
				$user = $req->fetch(PDO::FETCH_ASSOC);

				return $user;
				
			} else {
				
				error_log("mdp différent");				
				return false;
				
			}
			
		} catch(PDOException $e){
			
			$erreur = "Problème lors de la connexion au compte: " . $e->getMessage();
			
			return $erreur;
			
		}
    }
    
    public function inscription($login, $nom, $prenom, $mail, $password, $cpassword){
		error_log("model.php inscription");
		
		try{
			
			if(trim($login)!="" && trim($nom)!="" && trim($prenom)!="" && trim($mail)!="" && trim($password)!="" && trim($cpassword)!=""){
				
				if($password==$cpassword){
					
					$password = password_hash(trim($cpassword), PASSWORD_BCRYPT);
					
					$req = $this->pdo->prepare("INSERT INTO users VALUES (NULL, :login, :nom, :prenom, :mail, :password, FALSE);");
					
					$req->execute(["login" => $login, "nom" => $nom, "prenom" => $prenom, "mail" => $mail, "password" => $password]);
					
					return $req;
					
				} else{
					
					return false;
					
				}
				
			} else{
				
				return false;
				
			}
			
		}catch(PDOException $e){
			
			$erreur = "Problème lors de l'inscription: " . $e->getMessage();
			
			return $erreur;
			
		}
    }
    
    public function sort_prix($modulo){
		error_log("model.php sort_prix");
		
		$tri="";
		if($modulo==1){
			$tri="ORDER BY loutre_a_vendre.prix ASC;";
		} else{
			$tri="ORDER BY loutre_a_vendre.prix DESC;";
		}
		
		$req = $this->pdo->prepare("SELECT loutre_a_vendre.id, loutre_a_vendre.nom_loutre, loutre_a_vendre.prix, race_loutre.race FROM loutre_a_vendre, race_loutre WHERE race_loutre.id=loutre_a_vendre.id_race ".$tri);
		$req->execute();
		$t = $req->fetchAll(PDO::FETCH_ASSOC);
	
		return $t;
	}
	
	public function sort_race($modulo){
		error_log("model.php sort_race");
		
		$tri="";
		if($modulo==1){
			$tri="ORDER BY race_loutre.race ASC;";
		} else{
			$tri="ORDER BY race_loutre.race DESC;";
		}
		
		$req = $this->pdo->prepare("SELECT loutre_a_vendre.id, loutre_a_vendre.nom_loutre, loutre_a_vendre.prix, race_loutre.race FROM loutre_a_vendre, race_loutre WHERE race_loutre.id=loutre_a_vendre.id_race ".$tri);
		$req->execute();
		$t = $req->fetchAll(PDO::FETCH_ASSOC);
	
		return $t;
	}
    
    public function verif_login($login){
		error_log("model.php verif_login");
		
		try{
			
			$req = $this->pdo->prepare("SELECT login FROM users WHERE login SOUNDS LIKE :login;");
			$req->execute(["login" => $login]);
			$log = $req->fetch(PDO::FETCH_ASSOC);

			return $log;
			
		}catch(PDOException $e){

			$erreur = "Problème lors de la vérification du login: " . $e->getMessage();

			return $erreur;
			
		}
		
	}
}

?>
