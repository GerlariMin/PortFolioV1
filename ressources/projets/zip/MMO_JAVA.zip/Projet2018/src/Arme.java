//import java.util.ArrayList;
//import java.util.Scanner;

public class Arme extends Objet{
	//private ArrayList <Objet> inventaire;//liste dobjet que possedera un joueur
	private int degat;

	
	public int getDegat() {
		return degat;
	}
	public void setDegat(int degat) {
		this.degat = degat;
	}
	
	public Arme(String n){
		super();
		super.setNom(n);
		if(n == "hache" || n == "Hache"){
			this.degat=1;
		}
		if(n == "epee" || n == "Epee" || n == "�p�e" || n == "Ep�e"){
			this.degat=2;
		}
		if(n == "massue" || n == "Massue"){
			this.degat=3;
		}
	}
	
	public String toString() {
		return "Arme: \n" + super.getNom() + ", degat: " + this.degat;
	}
	
	public static void main(String[] args) {
		System.out.println("Saisissez l'arme que vous voulez utiliser:\n\t- Ep�e;\n\t- Hache;\n\t- Massue.");
		//Scanner sc = new Scanner(System.in);
		//String n = sc.nextLine();
		//sc.close();
		Arme a = new Arme("epee");//ne fonctionne pas si on utilise un scanner, surement pck il sagit dun appel statique et non dynamique
		System.out.println(a.degat);
		System.out.println(a.toString());
	}
}