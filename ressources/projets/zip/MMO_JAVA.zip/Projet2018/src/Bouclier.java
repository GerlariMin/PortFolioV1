
public class Bouclier extends Objet{

	private int defense;

	public Bouclier() {
		super.setNom("Bouclier");
		super.setEncombrement(3);
		super.setImpact(1);
		super.setManiabilite(1);
		this.setDefense(3);
	}

	private void setDefense(int d) {
		this.defense=d;
		}
	private int getDefense() {
		return this.defense;
	}
}
