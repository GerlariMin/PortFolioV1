import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Carte extends JFrame implements KeyListener{
	String plateau[][]=new String[16][16];
	private Joueur j;
	private Joueur j2;
	private Objet obj;
	private String c;
	private int n;
	private ArrayList <Objet> objmap = new ArrayList <Objet>();
	
	public Joueur getJ() {
		return this.j;
	}
	
	public void setJ(Joueur jj) {
		this.j = jj;
	}
	
	public Joueur getJ2() {
		return this.j2;
	}
	
	public void setJ2(Joueur jj2) {
		this.j2 = jj2;
	}
	
	public Objet getObj() {
		return this.obj;
	}
	
	public void setObj(Objet o) {
		this.obj = o;
	}
	
	public String getC() {
		return c;
	}

	public void setC(String c) {
		this.c = c;
	}
	
	public int getN() {
		return n;
	}
	
	public void setN(int nn) {
		this.n = nn;
	}
	
	public ArrayList <Objet> getObjmap() {
		return objmap;
	}

	public void setObjmap(ArrayList <Objet> objmap) {
		this.objmap = objmap;
	}
	
	public void ajouter(Objet o) {
		this.objmap.add(o);
	}
	public void supprimer(Objet o) {
		for(int i =0; i<this.objmap.size(); i++) {
			if(this.objmap.get(i) == o) {
				this.objmap.remove(i);
			}
		}
	}
	public void afficherObjMap() {
		for(int i = 0; i<this.objmap.size(); i++) {
			System.out.println(this.objmap.get(i));
		}
	}
	
	public void initialiseMap(){
		for(int i = 0; i<this.plateau.length; i++){
			for(int j = 0; j<this.plateau.length; j++){
				if(i == 0 || j == 0 || i == this.plateau.length-1 || j == this.plateau.length-1){
					this.plateau[i][j] = "#";     
				}else if(i==(this.plateau.length/4) && j ==(this.plateau.length/4)) {
					Objet o1 = new Arme("hache");
					o1.setPosx(i);
					o1.setPosy(j);
					this.ajouter(o1);
					this.plateau[i][j]="A";
				}else if(i==((this.plateau.length/4)*3) && j ==((this.plateau.length/4))*3) {
					Objet o2 = new Arme("epee");
					o2.setPosx(i);
					o2.setPosy(j);
					this.ajouter(o2);
					this.plateau[i][j]="A";
				}else if(i==(this.plateau.length/4) && j ==((this.plateau.length/4))*3) {
					Objet o3 = new Bouclier();
					o3.setPosx(i);
					o3.setPosy(j);
					this.ajouter(o3);
					this.plateau[i][j]="B";
				}else if(i==((this.plateau.length/4)*3) && j ==(this.plateau.length/4)) {
					Objet o4 = new Potion();
					o4.setPosx(i);
					o4.setPosy(j);
					this.ajouter(o4);
					this.plateau[i][j]="P";
				}else 
					this.plateau[i][j] = " ";
			}
		}
	}
	
	public void actualiserMap(Joueur j) {
		int x = j.getPosx();
		int y = j.getPosy();
		if(j instanceof PJ) {
				if(this.plateau[x][y]!= null && this.plateau[x][y]!= "#") {
					this.plateau[x][y] = "J";					
			}
		}else if(j instanceof PNJ) {
			if(this.plateau[x][y]!= null && this.plateau[x][y]!= "#") {
				this.plateau[x][y] = "M";
			}
		}
	}

	public void Combat() throws InterruptedException {
		System.out.println("Votre inventaire: " +this.j.getInventaire());
		this.setC("");
		do {
			System.out.println("Voulez-vous engager le combat ?\nAppuyez sur O pour oui ou sur N pour non.");
			Thread.sleep(2000);
		}while(this.getC()=="");
		if(this.getC()=="o") {
			System.out.println("Combat engage !");
			if(this.j.getInventaire().isEmpty()!=true) {
				this.setC("");
				do {
					System.out.println("voulez-vous utiliser un objet de votre inventaire ?");
					Thread.sleep(2000);
				}while(this.getC()=="");
					if(this.getC()=="o") {
					//System.out.println("Votre Inventaire contient le(s) element(s) suivant(s): ");
						this.j.afficherInventaire();
						this.setN(-1);
						do {
							System.out.println("Selectionnez l'objet voulu par son indice. "); 
							Thread.sleep(2000);
						}while(this.getN()==-1 || this.getN()>this.j.getInventaire().size());
						int index = this.getN()-1;
						
						this.j.UtiliserObjet(index);
						
						this.setObj(this.j.getO());
						this.j2.setBlessure(this.j2.getResistance()+this.j2.getBlessure()-this.j.getForce());
					}else if(this.getC()=="n"){
						this.j2.setBlessure(this.j2.getResistance()+this.j2.getBlessure()-this.j.getForce());
					}
			}else {
				System.out.println("Sante de "+ this.j2.getPseudo() +": "+ this.j2.getBlessure());
				this.j2.setBlessure(this.j2.getResistance()+this.j2.getBlessure()-this.j.getForce());
				System.out.println("Sante de "+ this.j2.getPseudo() +": "+ this.j2.getBlessure());
			}
		}else if(this.getC()=="n") {
			System.out.println("Combat non-engage !");
		}
		//System.out.println("Force j1: " + this.j.getForce());
		System.out.println("blessure de " +this.j2.getPseudo()+ ": "+this.j2.getBlessure());
		this.repaint();
	}
	
	public void verifier() {
		int x = this.getJ().getPosx();
		int y = this.getJ().getPosy();
		System.out.println("Voila ce qui vous entoure: ");
		System.out.println(this.plateau[x-1][y-1]+"|"+this.plateau[x-1][y]+"|"+this.plateau[x-1][y+1]);
		System.out.println(this.plateau[x][y-1]+"|"+this.plateau[x][y]+"|"+this.plateau[x][y+1]);
		System.out.println(this.plateau[x+1][y-1]+"|"+this.plateau[x+1][y]+"|"+this.plateau[x+1][y+1]);
	}

	public void seDeplacer(Joueur j, String c, Joueur j2) throws InterruptedException{
		this.setJ(j);
		this.setJ2(j2);
		//this.verifier();
		System.out.println("deplacement en cours");
		Thread.sleep(500);
		
		if(this.j.getPa()<2){
			System.out.println("Imposible d'attaquer ! Votre Puissance d'Action (PA) est insuffisante ! \nPA: " +this.j.getPa());
		
		}else if(c == "haut" && ((this.plateau[this.j.getPosx()-1][this.j.getPosy()] != "#") || (this.plateau[this.j.getPosx()-1][this.j.getPosy()] != " "))){
			if(this.plateau[this.j.getPosx()-1][this.j.getPosy()] == "M" || this.plateau[this.j.getPosx()-1][this.j.getPosy()] == "J") {//si on tombe sur un pnj ou un joueur
				System.out.println("Combat");
				this.Combat();//on engage le combat si on va en haut et quil y a quelquun en haut
				if(this.getJ2().getBlessure()<=0) {
					this.plateau[this.j.getPosx()][this.j.getPosy()]=" ";
					if(this.j instanceof PJ) {
						this.plateau[this.j.getPosx()-1][this.j.getPosy()]="J";
					}else if(this.j instanceof PNJ) {
						this.plateau[this.j.getPosx()-1][this.j.getPosy()]="M";
					}
					this.j.setPosx(this.j.getPosx()-1);
					System.out.println("reussi");
					//this.repaint();
				}
			}else if(this.plateau[this.j.getPosx()-1][this.j.getPosy()]=="A" || this.plateau[this.j.getPosx()-1][this.j.getPosy()]=="O" || this.plateau[this.j.getPosx()-1][this.j.getPosy()]=="P" || this.plateau[this.j.getPosx()-1][this.j.getPosy()]=="B") {
				System.out.println("Inventaire");
				for(int i = 0; i<this.objmap.size(); i++) {
					if(this.objmap.get(i).getPosx()==this.j.getPosx()-1 && this.objmap.get(i).getPosy()==this.j.getPosy()) {
						this.j.ajouter(this.objmap.get(i));
						this.objmap.remove(this.objmap.get(i));
						this.plateau[this.j.getPosx()][this.j.getPosy()]=" ";
						if(this.j instanceof PJ) {
							this.plateau[this.j.getPosx()-1][this.j.getPosy()]="J";
						}else if(this.j instanceof PNJ) {
							this.plateau[this.j.getPosx()-1][this.j.getPosy()]="M";
						}
						this.j.setPosx(this.j.getPosx()-1);
						System.out.println("reussi");
						//this.repaint();
					}
				}
			}else if(this.plateau[this.j.getPosx()-1][this.j.getPosy()]!="#"){//
				this.plateau[this.j.getPosx()][this.j.getPosy()]=" ";
				if(this.j instanceof PJ) {
					this.plateau[this.j.getPosx()-1][this.j.getPosy()]="J";
				}else if(this.j instanceof PNJ) {
					this.plateau[this.j.getPosx()-1][this.j.getPosy()]="M";
				}
				this.j.setPosx(this.j.getPosx()-1);
				System.out.println("deplacement reussi");
				//this.repaint();
			}else
				System.out.println("Deplacement invalide");
			
		}else if(c == "bas" && ((this.plateau[this.j.getPosx()+1][this.j.getPosy()] != "#" )|| (this.plateau[this.j.getPosx()+1][this.j.getPosy()] != " "))){
			if(this.plateau[this.j.getPosx()+1][this.j.getPosy()] == "M") {
				System.out.println("Combat");
				this.Combat();
				if(this.getJ2().getBlessure()<=0) {
					this.plateau[this.j.getPosx()][this.j.getPosx()]=" ";
					if(this.j instanceof PJ) {
						this.plateau[this.j.getPosx()+1][this.j.getPosy()]="J";
					}else if(this.j instanceof PNJ) {
						this.plateau[this.j.getPosx()+1][this.j.getPosy()]="M";
					}
					this.j.setPosx(this.j.getPosx()+1);
					this.plateau[this.j.getPosx()-1][this.j.getPosy()]=" ";///
					System.out.println("reussi");
					//this.repaint();
				}
				
			}else if(this.plateau[this.j.getPosx()+1][this.j.getPosy()]=="A" || this.plateau[this.j.getPosx()+1][this.j.getPosy()]=="O" || this.plateau[this.j.getPosx()+1][this.j.getPosy()]=="P" || this.plateau[this.j.getPosx()+1][this.j.getPosy()]=="B") {
				System.out.println("Inventaire");
				
				for(int i = 0; i<this.objmap.size(); i++) {
					
					if(this.objmap.get(i).getPosx()==this.j.getPosx()+1 && this.objmap.get(i).getPosy()==this.j.getPosy()) {
						this.j.ajouter(this.objmap.get(i));
						this.objmap.remove(this.objmap.get(i));
						this.plateau[this.j.getPosx()][this.j.getPosx()]=" ";
						if(this.j instanceof PJ) {
							this.plateau[this.j.getPosx()+1][this.j.getPosy()]="J";
						}else if(this.j instanceof PNJ) {
							this.plateau[this.j.getPosx()+1][this.j.getPosy()]="M";
						}
						this.j.setPosx(this.j.getPosx()+1);
						this.plateau[this.j.getPosx()-1][this.j.getPosy()]=" ";///
						System.out.println("reussi");
						//this.repaint();
					}
				}
			}else if(this.plateau[this.j.getPosx()+1][this.j.getPosy()]!="#"){//
				this.plateau[this.j.getPosx()][this.j.getPosx()]=" ";
				if(this.j instanceof PJ) {
					this.plateau[this.j.getPosx()+1][this.j.getPosy()]="J";
				}else if(this.j instanceof PNJ) {
					this.plateau[this.j.getPosx()+1][this.j.getPosy()]="M";
				}
				this.j.setPosx(this.j.getPosx()+1);
				this.plateau[this.j.getPosx()-1][this.j.getPosy()]=" ";///
				System.out.println("reussi");
				//this.repaint();
			}
			else
				System.out.println("Deplacement invalide");
			
		}else if(c == "gauche" && ((this.plateau[this.j.getPosx()][this.j.getPosy()-1] != "#")|| (this.plateau[this.j.getPosx()][this.j.getPosy()-1] != " "))){
			
			if(this.plateau[this.j.getPosx()-1][this.j.getPosy()] == "M") {
				System.out.println("Combat");
				this.Combat();
				if(this.getJ2().getBlessure()<=0) {
					this.plateau[this.j.getPosx()][this.j.getPosy()]=" ";
					if(this.j instanceof PJ) {
						this.plateau[this.j.getPosx()][this.j.getPosy()-1]="J";
					}else if(this.j instanceof PNJ) {
						this.plateau[this.j.getPosx()][this.j.getPosy()-1]="M";
					}
					j.setPosy(j.getPosy()-1);
					System.out.println("reussi");
					//this.repaint();
				}
				
			}else if(this.plateau[this.j.getPosx()][this.j.getPosy()-1]=="A" || this.plateau[this.j.getPosx()][this.j.getPosy()-1]=="O" || this.plateau[this.j.getPosx()][this.j.getPosy()-1]=="P" || this.plateau[this.j.getPosx()][this.j.getPosy()-1]=="B") {
				System.out.println("Inventaire");
				for(int i = 0; i<this.objmap.size(); i++) {
					if(this.objmap.get(i).getPosx()==this.j.getPosx() && this.objmap.get(i).getPosy()==this.j.getPosy()-1) {
						this.j.ajouter(this.objmap.get(i));
						this.objmap.remove(this.objmap.get(i));
						this.plateau[this.j.getPosx()][this.j.getPosy()]=" ";
						if(this.j instanceof PJ) {
							this.plateau[this.j.getPosx()][this.j.getPosy()-1]="J";
						}else if(this.j instanceof PNJ) {
							this.plateau[this.j.getPosx()][this.j.getPosy()-1]="M";
						}
						j.setPosy(j.getPosy()-1);
						System.out.println("reussi");
						//this.repaint();
					}
				}
			}else if(this.plateau[this.j.getPosx()][this.j.getPosy()-1]!="#"){//
				this.plateau[this.j.getPosx()][this.j.getPosy()]=" ";
				if(this.j instanceof PJ) {
					this.plateau[this.j.getPosx()][this.j.getPosy()-1]="J";
				}else if(this.j instanceof PNJ) {
					this.plateau[this.j.getPosx()][this.j.getPosy()-1]="M";
				}
				j.setPosy(j.getPosy()-1);
				System.out.println("reussi");
				//this.repaint();
			}else
				System.out.println("Deplacement invalide");
			
			
		}else if(c == "droite" && ((this.plateau[this.j.getPosx()][this.j.getPosy()+1] != "#") || (this.plateau[this.j.getPosx()][this.j.getPosy()+1] != " "))){
			System.out.println("Vous effectuez le deplacement vers la droite");
			if(this.plateau[this.j.getPosx()][this.j.getPosy()+1] == "M") {
				System.out.println("Combat");
				this.Combat();
				//this.getJ2().setBlessure(0);
				if(this.getJ2().getBlessure()<=0) {
					this.plateau[this.j.getPosx()][this.j.getPosy()]=" ";
					if(this.j instanceof PJ) {
						this.plateau[this.j.getPosx()][this.j.getPosy()+1]="J";
					}else if(this.j instanceof PNJ) {
						this.plateau[this.j.getPosx()][this.j.getPosy()+1]="M";
					}
					this.j.setPosy(this.j.getPosy()+1);
					System.out.println("deplacement reussi");
					//this.repaint();
				}
				
			}else if(this.plateau[this.j.getPosx()][this.j.getPosy()+1]=="A" || this.plateau[this.j.getPosx()][this.j.getPosy()+1]=="O" || this.plateau[this.j.getPosx()][this.j.getPosy()+1]=="P" || this.plateau[this.j.getPosx()][this.j.getPosy()+1]=="B") {
				System.out.println("Ajout a l'Inventaire");
				
				for(int i = 0; i<this.objmap.size(); i++) {
					
					if(this.objmap.get(i).getPosx()==this.j.getPosx() && this.objmap.get(i).getPosy()==this.j.getPosy()+1) {
						
						this.j.ajouter(this.objmap.get(i));
						this.objmap.remove(this.objmap.get(i));
						System.out.println(this.j.getInventaire());
						this.plateau[this.j.getPosx()][this.j.getPosy()]=" ";
						if(this.j instanceof PJ) {
							this.plateau[this.j.getPosx()][this.j.getPosy()+1]="J";
						}else if(this.j instanceof PNJ) {
							this.plateau[this.j.getPosx()][this.j.getPosy()+1]="M";
						}
						this.j.setPosy(this.j.getPosy()+1);
						System.out.println("deplacement reussi");
						//this.repaint();
					}
				}
			}else if(this.plateau[this.j.getPosx()][this.j.getPosy()+1]!="#"){//
				this.plateau[this.j.getPosx()][this.j.getPosy()]=" ";
				if(this.j instanceof PJ) {
					this.plateau[this.j.getPosx()][this.j.getPosy()+1]="J";
				}else if(this.j instanceof PNJ) {
					this.plateau[this.j.getPosx()][this.j.getPosy()+1]="M";
				}
				this.j.setPosy(this.j.getPosy()+1);
				System.out.println("deplacement reussi");
				//this.repaint();
			}else
				System.out.println("Deplacement invalide");	
			
		}else {
			System.out.println("Impossible de se déplacer");
		}
		
		this.actualiserMap(this.j);
		this.actualiserMap(this.j2);
		this.repaint();
	}

	public String toString(){
		String c ="";
		for(int i = 0; i<this.plateau.length; i++){
			for(int j = 0; j<this.plateau.length; j++){
				c += (this.plateau[i][j] + " ");
			}
			c += "\n";
		}
		return c;
	}
	
	public Carte() {
		super.setTitle("EHLPTMMMORPGSVR");
		Toolkit atk = Toolkit.getDefaultToolkit();
		Dimension d = atk.getScreenSize();
		int w = (int) (d.getWidth()/2);
		int h = (int) (d.getHeight()/2);
		this.setSize(w, h);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setLocationRelativeTo(null); 
		String[] titre = {"A", "B", "C", "D", "E", "F", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R"};
		this.initialiseMap();
		JTable t = new JTable(plateau, titre);
		t.setBackground(Color.LIGHT_GRAY);
		t.setForeground(Color.BLUE);
		t.setSize(w, h);
		this.add(t, BorderLayout.CENTER);
		JTextArea a = new JTextArea();
		a.setBackground(Color.CYAN);
		this.add(a, BorderLayout.SOUTH);
		a.addKeyListener(this);
		//t.addKeyListener(this);
		this.setVisible(true);
	}
	
	public static void main(String[] args) throws InterruptedException {
		Carte c = new Carte();
		PJ j1= new PJ("Joueur humain");
		PNJ j2= new PNJ();
		Tirage t = new Tirage();
		boolean tourj = true;
		boolean finpartie = false;
		
		System.out.println("\t\t\t== DEBUT ==");
		
		j1.setPosx(1); j1.setPosy(1);
		j2.setPosx(14); j2.setPosy(14);
		c.actualiserMap(j1); c.actualiserMap(j2);
		//c.sauve("Text");
		while(finpartie == false) {
			if(tourj == true) {
				c.setJ(j1);
				c.setJ2(j2);
			}else if(tourj == false) {
				c.setJ2(j1);
				c.setJ(j2);
			}
			System.out.println("Au tour de: " + c.j.getPseudo());
			c.verifier();
			if(tourj==true) {
				System.out.println("Vous avez " + c.j.getPa() +" PA restant(s)");
				System.out.println("Que voulez-vous faire ?\n\t0-Quitter le jeu\n\t1-Vous deplacer (3PA)\n\t2-Utiliser objet(Cout variable)\n\t3-Voir votre inventaire(0PA)\n\t4-Deposer un objet(2PA)");
				c.setN(-1);
				do {
					Thread.sleep(3000);
					
				}while(c.getN()==-1);
				if(c.getN()==0) {
					System.exit(0);
				}else if(c.getN()==1) {
					if(c.getN()==1) {
						c.setC("");
						do {
							System.out.println("Utilisez les fleches du clavier pour vous deplacer.");
							Thread.sleep(2000);
						}while(c.getC()=="");
							c.seDeplacer(c.j, c.getC(), c.j2);
					}
					c.j.setPa(c.j.getPa()-3);
				}else if(c.getN()==2) {
					if(c.j.getInventaire().isEmpty()==true) {
						c.j.afficherInventaire();
					}else {
						c.j.afficherInventaire();
						c.setN(-1);
						do {
							System.out.println("Selectionnez un indice en partant de 0 avec les touches du clavier.");
							Thread.sleep(2000);
						}while(c.getN()==-1 || c.getN()>=c.j.getInventaire().size());
						c.j.UtiliserObjet(c.getN());
						//c.j.setPa(c.getJ().getPa()-3);
					}
				}else if(c.getN()==3) {
					c.j.afficherInventaire();
				}else if(c.getN()==4) {
					if(c.j.getInventaire().isEmpty()==true) {
						c.j.afficherInventaire();
					}else {
						c.j.afficherInventaire();
						c.setN(-1);
						do {
							System.out.println("Selectionnez un indice en partant de 0 avec les touches du clavier.");
							Thread.sleep(2000);
						}while(c.getN()==-1 || c.getN()>=c.j.getInventaire().size());
						c.j.deposerObjet(c.getN());
						c.j.setPa(c.j.getPa()-2);
					}
				}
			}else if(tourj==false) {
				System.out.println("Monstre essaye de se deplacer");
				float i = (float) ((Math.random() * (4-1) +1));
				if(i<1) {
					c.seDeplacer(c.j, "gauche", c.j2);
				}else if(i>2){
					c.seDeplacer(c.j, "haut", c.j2);
				}else if(i>3) {
					c.seDeplacer(c.j, "droite", c.j2);
				}else if(i>=4) {
					c.seDeplacer(c.j, "bas", c.j2);
				}
			}
		
		//c.j.setPa(c.j.getPa()+2);
		/*tirage*/
		int tir = (int) (Math.random() * (4-1) +1);
		t.t(tir, j1);
		Thread.sleep(1000);
		try {
			  if(System.getProperty("os.name" ).startsWith("Windows" ))
			    Runtime.getRuntime().exec("cls" );
			  else
			    Runtime.getRuntime().exec("clear" );
			} catch(Exception excpt) {
			  for(int i=0;i<100;i++)
			    System.out.println();
		}
		if(tourj==false) {
			tourj=true;
		}else if (tourj==true) {
			tourj=false;
		}
		if(c.j.getBlessure()<1 || c.j2.getBlessure()<1) {
			finpartie=true;
			if(c.j.getBlessure()<1) {
				System.out.println(c.j2.getPseudo()+" a perdu !");
			}else if(c.j2.getBlessure()<1) {
				System.out.println(c.j2.getPseudo()+" a perdu !");
			}
			System.out.println("\t\t\t== Fin de partie ==");
		}
		}
	}
		
	public void keyPressed(KeyEvent e) {
        // TODO Auto-generated method stub
        if((e.getKeyCode()==KeyEvent.VK_UP)) {
        	System.out.println("vous avez apuyer sur haut");
        	this.setC("haut");
        }else if((e.getKeyCode()==KeyEvent.VK_DOWN)) {
        	System.out.println("vous avez apuyer sur bas");
        	this.setC("bas");
        }else if((e.getKeyCode()==KeyEvent.VK_LEFT)) {
        	System.out.println("vous avez apuyer sur gauche");
        	this.setC("gauche");
        }else if((e.getKeyCode()==KeyEvent.VK_RIGHT)) {
        	System.out.println("vous avez apuyer sur droite");
        	this.setC("droite");
        }else if((e.getKeyCode()==KeyEvent.VK_Q)) {
        	System.out.println("vous avez apuyer sur Q");
        	this.setC("q");
        }else if((e.getKeyCode()==KeyEvent.VK_O)) {
        	System.out.println("vous avez apuyer sur O");
        	this.setC("o");
        }else if((e.getKeyCode()==KeyEvent.VK_N)) {
        	System.out.println("vous avez apuyer sur N");
        	this.setC("n");
        }else if((e.getKeyCode()==KeyEvent.VK_0)) {
        	System.out.println("vous avez apuyer sur 0");
        	this.setN(0);
        }else if((e.getKeyCode()==KeyEvent.VK_1)) {
        	System.out.println("vous avez apuyer sur 1");
        	this.setN(1);
        }else if((e.getKeyCode()==KeyEvent.VK_2)) {
        	System.out.println("vous avez apuyer sur 2");
        	this.setN(2);
        }else if((e.getKeyCode()==KeyEvent.VK_3)) {
        	System.out.println("vous avez apuyer sur 3");
        	this.setN(3);
        }else if((e.getKeyCode()==KeyEvent.VK_4)) {
        	System.out.println("vous avez apuyer sur 4");
        	this.setN(4);
        }else if((e.getKeyCode()==KeyEvent.VK_5)) {
        	System.out.println("vous avez apuyer sur 5");
        	this.setN(5);
        }else if((e.getKeyCode()==KeyEvent.VK_6)) {
        	System.out.println("vous avez apuyer sur 6");
        	this.setN(6);
        }else if((e.getKeyCode()==KeyEvent.VK_7)) {
        	System.out.println("vous avez apuyer sur 7");
        	this.setN(7);
        }else if((e.getKeyCode()==KeyEvent.VK_8)) {
        	System.out.println("vous avez apuyer sur 8");
        	this.setN(8);
        }else if((e.getKeyCode()==KeyEvent.VK_9)) {
        	System.out.println("vous avez apuyer sur 9");
        	this.setN(9);
        }
    }
 
 
 
    @Override
    public void keyReleased(KeyEvent e) {
        // TODO Auto-generated method stub
         
    }
 
 
 
    @Override
    public void keyTyped(KeyEvent e) {
        // TODO Auto-generated method stub
         
    }
    
    public void charger(String NomFic){
		try{
			while(this.plateau.length!=0){
				this.remove(0);
			}
			FileReader fr = new FileReader(NomFic);
			BufferedReader br = new BufferedReader(fr);
			String line = br.readLine();
			
			for(int i =0; line!=null; i++){
				StringTokenizer st = new StringTokenizer(line," ");
				Carte c = new Carte();
				for(int j=0; line !=null; j++) {
					c.plateau[i][j]=st.nextToken();
					System.out.println(line);
					System.out.println(st.nextToken());
					line = br.readLine();
					c.repaint();
				}
				System.out.println(line);
				System.out.println(st.nextToken());
				line = br.readLine();		
			}
			
			br.close();
			fr.close();
		}catch( IOException e ){
			System.err.println(e);
		}
	}
	public void sauve(String NomFic){
		System.out.println("Sauvegarde");
		try{
		FileWriter fw = new FileWriter(NomFic);
		BufferedWriter bw = new BufferedWriter(fw);
		for(int i = 0; i<this.plateau.length; i++){
			for(int j = 0; j<this.plateau.length; j++) {
				bw.write(this.getTitle() + " ");
			}
			bw.write("\n");
		}
		bw.close();
		fw.close();
		}catch(IOException e){
			System.err.println(e);
		}
	}

}
