import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Scanner;

public class Joueur{ //a voir si cest une interface ou non
		private String[][] plateau; //le plateau contiendra le nom de chaque element present dans une case
		private String pseudo;
		private int niveau;
		private int px;
		private int blessure;
		private int pa;
		private int force;
		private int adresse;
		private int resistance;
		private int posx; //position du joueur a indiquer dans le tableau carte qui sera envoyï¿½ en parametre (du constructeur)
		private int posy;
		private Objet o;
		private ArrayList <Objet> inventaire = new ArrayList <>();
		private String c;
		private int n;
		
		public String getC() {
			return c;
		}
		public void setC(String c) {
			this.c = c;
		}
		
		public int getN() {
			return n;
		}
		public void setN(int nn) {
			this.n = nn;
		}
		
		//Inventaire
		public ArrayList <Objet> getInventaire() {
			return inventaire;
		}
		public void setInventaire(ArrayList <Objet> inventaire) {
			this.inventaire = inventaire;
		}
		public void ajouter(Objet o) {
			this.inventaire.add(o);
		}
		public void supprimer(Objet o) {
			for(int i =0; i<this.inventaire.size(); i++) {
				if(this.inventaire.get(i) == o) {
					this.inventaire.remove(i);
				}
			}
		}
		public void afficherInventaire() {
			if(this.inventaire.isEmpty()==true) {
				System.out.println("Inventaire vide !");
			}else {
				for(int i = 0; i<this.inventaire.size(); i++) {
					System.out.println(this.inventaire.get(i));
				}
			}
		}
		//Fin Inventaire
		//Caractéristiques
		public String getPseudo() {
			return this.pseudo;//pseudo;
		}
		public void setPseudo(String pseudo) {
			this.pseudo = pseudo;
		}
		public int getForce() {
			return force;
		}
		public void setForce(int force) {
			this.force = force;
		}
		public int getAdresse() {
			return adresse;
		}
		public void setAdresse(int adresse) {
			this.adresse = adresse;
		}
		public int getResistance() {
			return resistance;
		}
		public void setResistance(int resistance) {
			this.resistance = resistance;
		}
		//Fin Caractéristiques
		//Position
		public int getPosx() {
			return posx;
		}
		public void setPosx(int posx) {
			this.posx = posx;
		}
		public int getPosy() {
			return posy;
		}
		public void setPosy(int posy) {
			this.posy = posy;
		}
		public String[][] getPlateau() {
			return plateau;
		}
		public void setPlateau(String[][] plateau) {
			this.plateau = plateau;
		}
		//Fin Position
		//Santé et niveau/ XP
		public int getNiveau() {
			return niveau;
		}
		public void setNiveau(int niveau) {
			this.niveau = niveau;
		}		
		public int getPx() {
			return px;
		}
		public void setPx(int px) {
			this.px = px;
		}		
		public int getBlessure() {
			return blessure;
		}
		public void setBlessure(int blessure) {
			this.blessure = blessure;
		}
		public int getPa() {
			return pa;
		}
		public void setPa(int pa) {
			this.pa = pa;
		}
		//fin
		//Objet
		public Objet getO() {
			return o;
		}
		public void setO(Objet o) {
			this.o = o;
		}
		
		public Joueur() {
			this.niveau = 1;
			this.blessure = 6;
			this.px = 0;
			this.pa = 24;
		}
		
		public void UtiliserObjet(int index) throws InterruptedException{
			if(this.getInventaire().isEmpty()==true) {
				System.out.print("Inventaire vide !");
			}else {
				System.out.println("Votre Inventaire contient le(s) objet(s) suivant(s): ");
				this.afficherInventaire();
				
				this.setO(this.inventaire.get(index));
				if(this.o instanceof Arme) { // si l'objet est une arme
					this.setForce(this.getForce()+this.o.getImpact()-this.o.getEncombrement());
					this.setPa(this.getPa()-3);
				}else if(this.o instanceof Potion) { // si lobjet est une potion
					// on gonfle les stats du joueur + on lui redonne un peu de vie
					this.setBlessure(this.getBlessure()+1);
					this.setNiveau(this.getNiveau()+1);
					this.setResistance(this.getResistance()+1);
					this.setPa(this.getPa()-4);
					this.setPx(this.getPx()+5);
					if(this.getPx()>=10) {
						this.setNiveau(this.getNiveau()+1);
						this.setPx(this.getPx()-this.getPx());
					}
				}/*else if(this.getO() instanceof Vetement) {
					this.setForce(this.getForce()+this.o.getImpact()-this.o.getEncombrement());
				}*/else if(this.getO() instanceof Bouclier) {
					this.setForce(this.getForce()+o.getImpact());
					this.setResistance(this.getResistance()+1);
				}
			}
		}
		
		public void deposerObjet(int index) {
			if(this.getInventaire().isEmpty()==true) {
				System.out.print("Inventaire vide !");
			}else {
				System.out.println("Votre Inventaire contient le(s) objet(s) suivant(s): ");
				this.afficherInventaire();
				this.inventaire.remove(index);
				System.out.println("Votre Inventaire contient maintenant le(s) objet(s) suivant(s): ");
				this.afficherInventaire();
			}
		}
		
		public String toString(){
			//System.out.println("\t=== Joueur ===");
			switch(this.blessure){
			case 5:
				return "-> Niveau: " +this.niveau + "\n-> Points d'Action (PA): " +this.pa + " PA" + "\n-> Experience: " + this.px +" px\n-> Etat: Blessures superficielles";
			case 4: 
				return "-> Niveau: " +this.niveau + "\n-> Points d'Action (PA): " +this.pa + " PA" + "\n-> Experience: " + this.px +" px\n-> Etat: Legerement blesse";
			case 3:
				return "-> Niveau: " +this.niveau + "\n-> Points d'Action (PA): " +this.pa + " PA" + "\n-> Experience: " + this.px +" px\n-> Etat: Blesse";
			case 2:
				return "-> Niveau: " +this.niveau + "\n-> Points d'Action (PA): " +this.pa + " PA" + "\n-> Experience: " + this.px +" px\n-> Etat: Gravement blesse";
			case 1:
				return "-> Niveau: " +this.niveau + "\n-> Points d'Action (PA): " +this.pa + " PA" + "\n-> Experience: " + this.px +" px\n-> Etat: Inconscient";
			case 0:
				return this.getPseudo() + "\n-> Niveau: " +this.niveau + "\n-> Points d'Action (PA): " +this.pa + " PA" + "\n-> Experience: " + this.px +" px\n-> Etat: Mort";
			default:
				return "-> Niveau: " +this.niveau + "\n-> Points d'Action (PA): " +this.pa + " PA" + "\n-> Experience: " + this.px +" px\n-> Etat: En pleine forme !";
			}
		}

		/*public static void main(String[] args) {
			Joueur j = new Joueur();
			System.out.println(j.toString());
			j.blessure=6;
			System.out.println(j.toString()); 
		}*/
		
}