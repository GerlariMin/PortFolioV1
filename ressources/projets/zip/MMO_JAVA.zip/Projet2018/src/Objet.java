public class Objet {
	
	private int quantite;
	private String nom;
	private int encombrement;
	private int maniabilite;
	private int solidite;
	private int impact;
	private int posx;
	private int posy;
	
	public int getEncombrement() {
		return encombrement;
	}
	public void setEncombrement(int encombrement) {
		this.encombrement = encombrement;
	}
	public int getManiabilite() {
		return maniabilite;
	}
	public void setManiabilite(int maniabilite) {
		this.maniabilite = maniabilite;
	}
	public int getSolidite() {
		return solidite;
	}
	public void setSolidite(int solidite) {
		this.solidite = solidite;
	}
	public int getImpact() {
		return impact;
	}
	public void setImpact(int impact) {
		this.impact = impact;
	}
	public int getQuantite() {
		return quantite;
	}
	public void setQuantite(int quantite) {
		this.quantite = quantite;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public int getPosx() {
		return posx;
	}
	public void setPosx(int posx) {
		this.posx = posx;
	}
	public int getPosy() {
		return posy;
	}
	public void setPosy(int posy) {
		this.posy = posy;
	}
	
	public Objet(){
		this.nom = "Objet quelconque";
		this.quantite = 1;
		this.encombrement = 2;//sur une base de 5
		this.maniabilite = 2;
		this.solidite = 1;
		this.impact = 2;
	}
	
	public Objet(String nom, int quantite,int encombrement, int mania, int solid, int imp) {
		this.nom = nom;
		this.quantite = quantite;
		this.encombrement = encombrement;
		this.maniabilite = mania;
		this.solidite = solid;
		this.impact = imp;
	}
	
	public String toString(){
		return "Objet: "+this.nom + ", quantité: " +this.quantite 
				+".\nEncombrement: " + this.encombrement +", maniabilité: " + this.maniabilite +", solidité: "
				+ this.solidite + ", impact(dégâts): " + this.impact +".";
	}
	public static void main(String[] args) {
		Objet o = new Objet();
		System.out.println(o.toString());
	}
}