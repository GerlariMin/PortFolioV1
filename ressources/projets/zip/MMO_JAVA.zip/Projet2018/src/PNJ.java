public class PNJ extends Joueur{
	public PNJ() {
		super.setPseudo("Monstre");
		super.setForce(3);
		super.setAdresse(2);
		super.setResistance(2);
	}
	
	/*public PNJ(String n) {
		n.toLowerCase();
		if(n == "eclaireur") {
			super.setForce(2); //sur une echelle de 5
			super.setAdresse(5);
			super.setResistance(3);
		}else if(n == "soldat") {
			super.setForce(5); //sur une echelle de 5
			super.setAdresse(2);
			super.setResistance(3);
		}else if(n == "tank" ){
			super.setForce(3); //sur une echelle de 5
			super.setAdresse(1);
			super.setResistance(5);
		}
	}*/
	
	public String toString() {
		return "\t=== PNJ ===\n" + super.toString() +"\n == Caracteristiques ==\n-> Force: " + super.getForce() + "\n-> Adresse: " + super.getAdresse() + "\n-> Resistance: " + super.getResistance()+ "\n == Capacitées ==\n-> Initiative: N/A\n-> Attaque: N/A\n-> Esquive: N/A\n-> Défense: N/A\n-> Dégâts: N/A";
	}
	
	/*public static void main(String[] args) {
		PNJ pnj = new PNJ();
		System.out.println(pnj.toString());
	}*/
}