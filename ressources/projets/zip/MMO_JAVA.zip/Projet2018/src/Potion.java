public class Potion extends Objet{
	private int soin;

	public int getSoin() {
		return soin;
	}

	public void setSoin(int soin) {
		this.soin = soin;
	}
	
	public Potion() {
		super();
		super.setNom("Potion");
		super.setQuantite(1);
		this.soin = 1;
	}
	
	public String toString() {
		return "Potion";
	}
	
	public static void main(String[] args) {
		Potion p = new Potion();
		System.out.println(p.soin);
		System.out.println(p.toString());
	}
}