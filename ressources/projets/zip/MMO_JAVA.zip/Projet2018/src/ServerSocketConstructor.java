import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;

	public class ServerSocketConstructor {

	   public static void main(String[] args) {

	      for(int port = 1; port <= 65535; port++){
	         try {
	            //ServerSocket sSocket = new ServerSocket(port);
	        	 String IP = "192.168.10.10";

	        	 int fileAttente = 100;

	        	 ServerSocket sSocket = new ServerSocket(port, fileAttente, InetAddress.getByName(IP));
	         } catch (IOException e) {
	            System.err.println("Le port " + port + " est deja utilise ! ");
	         }
	      }
	   }
	}
