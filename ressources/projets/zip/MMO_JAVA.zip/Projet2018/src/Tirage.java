
public class Tirage {
	public void t(int i, Joueur j) {
		System.out.println("\t\t\t=== Tirage mystère ! ===");
		if(i==1) {
			System.out.println("Vous avez gagner un objet surprise dans votre inventaire !");
			Objet o = new Potion();
			j.ajouter(o);
		}else if(i==2) {
			System.out.println("Vous avez gagner un objet surprise dans votre inventaire !");
			Objet o = new Bouclier();
			j.ajouter(o);
		}else if(i==3) {
			System.out.println("Chanceux !");
			j.setNiveau(j.getNiveau()+1);
			j.setAdresse(j.getAdresse()+1);
			j.setForce(j.getForce()+1);
			j.setResistance(j.getResistance()+1);
			j.setPa(j.getPa()+10);
		}else if(i==4) {
			System.out.println("Pas de chance !");
			j.setNiveau(j.getNiveau()+1);
			j.setAdresse(j.getAdresse()-1);
			j.setForce(j.getForce()-1);
			j.setResistance(j.getResistance()-1);
			j.setPa(j.getPa()+3);
		}else { 
			int c = (int) (Math.random()*(4-1)+1);
			this.t(c, j);
		}
	}
}
