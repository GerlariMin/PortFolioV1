Projet HTML: Site de jeu rétro games.
Etudiants sur le projet: MENDES Virgil, THAMBITHURAI Madushan, MINBIELLE Morgan.
Les images proviennent en grande partie de nous même sauf quelques unes qui viennent d'internet comme celles des réseaux sociaux ou du salon de la Paris Games Week.
Notes pour le professeur: pour profiter de l'affichage complet il faut une connexion internet sinon le style graphique du texte n'apparait pas...
